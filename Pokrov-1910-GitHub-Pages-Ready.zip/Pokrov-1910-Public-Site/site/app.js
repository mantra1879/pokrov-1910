import * as THREE from './assets/three.module.js';
import { OrbitControls } from './assets/OrbitControls.js';
import { buildCity } from './city.js';
import { GEOGRAPHY } from './geography.js';
import { PLACES, PHOTOS, METHOD, evidenceFor } from './content.js';
import { eveningState } from './street-infrastructure.js';

import { biographyHTML } from './people-content.js';
import { makeCamera, resizeCamera, ISO_DIRECTION, metresPerPixel, sceneRect } from './camera-rig.js';
import { createSkyEnvironment } from './architectural-materials.js';
import { fitSunShadow } from './shadow-fit.js';

const $=id=>document.getElementById(id);
const viewport=$('viewport');
const state={view:'iso',labels:true,life:!matchMedia('(prefers-reduced-motion: reduce)').matches,tour:false,selection:null,evidence:false,comparison:false,measuring:false,quality:innerWidth<700?'low':'balanced'};
let renderer,scene,camera,controls,city,flight=null,yaw=-Math.PI/2,pitch=0,previous=performance.now(),elapsed=0;
const keys=new Set(),pointer={down:false,moved:0,x:0,y:0,id:null};
const mobile=()=>innerWidth<700;
function openArchive(tab='photos'){
  document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  const content=$('archive-content');
  if(tab==='photos')content.innerHTML=`<div class="photo-grid">${PHOTOS.map(p=>`<figure><a href="./assets/${p.file}" target="_blank" rel="noopener"><img src="./assets/${p.file}" alt="${p.title}" loading="lazy"></a><figcaption><h3>${p.title}</h3><p>${p.caption}</p><a href="${p.url}" target="_blank" rel="noopener">${p.credit}</a>${p.license?` · <a href="${p.licenseUrl}" target="_blank" rel="noopener">${p.license}</a><p class="photo-changes">${p.changes}</p>`:''}</figcaption></figure>`).join('')}</div>`;
  if(tab==='map')content.innerHTML=`<figure><a href="./assets/plan-1788-lubov.jpg" target="_blank" rel="noopener"><img class="old-map" src="./assets/plan-1788-lubov.jpg" alt="Подлинный регулярный план Покрова, утверждённый 9 декабря 1788 года"></a><figcaption class="map-info"><p><b>План Владимирского наместничества городу Покрову. 9 декабря 1788 года.</b></p><p>Это проект регулярной планировки, предшествующий моделируемому периоду. Он использован для понимания структуры кварталов, а не как готовый кадастр на 1910 год. Река Шитка и дорога на Владимир помогают сопоставить его с городом. Изображение показано в исходной ориентации; оно не совмещено автоматически с видом сверху.</p><a href="https://lubovbezusl.ru/publ/istorija/pokrov/o/58-1-0-1555" target="_blank" rel="noopener">Источник репродукции</a></figcaption></figure>`;
  if(tab==='method'){
    content.innerHTML=METHOD;const checkbox=$('evidence-toggle');checkbox.checked=state.evidence;checkbox.addEventListener('change',()=>{state.evidence=checkbox.checked;if(city){city.background.visible=!state.evidence;renderer.shadowMap.needsUpdate=true;}document.querySelector('[data-layer=ordinary]').checked=!state.evidence;});
  }
  if(!$('archive-dialog').open)$('archive-dialog').showModal();
  keys.clear();
}
$('archive-button').onclick=()=>openArchive();$('method-button').onclick=()=>openArchive('method');$('error-archive').onclick=()=>openArchive();
$('help-button').onclick=()=>{$('help-dialog').showModal();keys.clear();};
document.querySelectorAll('.close-dialog').forEach(b=>b.onclick=()=>b.closest('dialog').close());
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>openArchive(b.dataset.tab));
document.querySelectorAll('dialog').forEach(d=>{d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});});
$('places-list').innerHTML=PLACES.map((p,i)=>`<button class="place" data-place="${p.id}"><span class="place-number">${String(i+1).padStart(2,'0')}</span><span>${p.short}<small>${p.subtitle}</small></span></button>`).join('');
$('places-toggle').onclick=()=>{const c=document.querySelector('.places').classList.toggle('collapsed');$('places-toggle').textContent=c?'+':'−';$('places-toggle').setAttribute('aria-expanded',String(!c));};
if(mobile()){document.querySelector('.places').classList.add('collapsed');$('places-toggle').textContent='+';$('places-toggle').setAttribute('aria-expanded','false');}

function closeDetail(){closeComparison();state.selection=null;$('detail').hidden=true;document.querySelectorAll('[data-place]').forEach(b=>b.classList.remove('active'));}
function showPlace(id,move=true){
  closeComparison();
  if(state.measuring)toggleMeasurement();
  const p=PLACES.find(p=>p.id===id);if(!p||!camera)return;state.selection=id;stopTour();
  document.querySelectorAll('.place').forEach(b=>b.classList.toggle('active',b.dataset.place===id));
  $('detail').innerHTML=`<button class="detail-close" aria-label="Закрыть карточку">×</button>${p.photo?`<a href="./assets/${p.photo}" target="_blank" rel="noopener" aria-label="Открыть фотографию: ${p.title}"><img class="detail-image" src="./assets/${p.photo}" alt="${p.title}"></a>`:''}<div class="detail-content"><span class="eyebrow">${p.date}</span><h2>${p.title}</h2><div class="address">${p.address}</div>${p.periodNote?`<p class="period-note">${p.periodNote}</p>`:''}<p>${p.text}</p>${biographyHTML(p.id)}<div class="evidence-facts"><strong>Подтверждено источниками</strong><p>${evidenceFor(p).known}</p><strong>Приближённо / требует проверки</strong><p>${evidenceFor(p).inferred}</p></div>${p.photo?`<p class="source">${p.photoCaption}${p.photoSource?`<br><a href="${p.photoSource}" target="_blank" rel="noopener">${p.photoCredit||'Оригинал фотографии'}</a>${p.photoLicense?` · <a href="${p.photoLicenseUrl}" target="_blank" rel="noopener">${p.photoLicense}</a>`:''}`:''}</p>`:''}<a class="source" href="${p.source}" target="_blank" rel="noopener">${p.sourceName}</a>${(p.sources||[]).map(s=>`<a class="source secondary-source" href="${s.url}" target="_blank" rel="noopener">${s.title}</a>`).join('')}<div class="detail-actions">${p.photo?'<button class="compare-button">Модель рядом с фото</button>':''}<button class="walk-there">Пройти к этому месту</button></div></div>`;
  $('detail').hidden=false;const compareButton=$('detail').querySelector('.compare-button');if(compareButton)compareButton.onclick=()=>openComparison(p);$('detail').querySelector('.detail-close').onclick=closeDetail;$('detail').querySelector('.walk-there').onclick=()=>{setView('walk',p);closeDetail();};
  if(mobile()){document.querySelector('.places').classList.add('collapsed');$('places-toggle').textContent='+';$('places-toggle').setAttribute('aria-expanded','false');}
  if(move){
    const [x,z]=GEOGRAPHY.landmarks[id].point,target=new THREE.Vector3(x,p.height*.28,z);
    if(state.view==='walk')setView('walk',p);
    else if(camera.isOrthographicCamera){
      const dir=state.view==='plan'?new THREE.Vector3(0,1,.00001):ISO_DIRECTION;
      flyTo(target.clone().addScaledVector(dir,1050),target,1.1,camera.userData.span/(p.focusSpan|| (p.height>20?155:120)));
    }else{const d=p.height>20?118:100,offset=p.view||[-d*.9,p.height>20?75:53,d];flyTo(new THREE.Vector3(x+offset[0],offset[1],z+offset[2]),target,1.2);}
  }
}
document.querySelectorAll('.place').forEach(b=>b.onclick=()=>showPlace(b.dataset.place));
const labelObjects=[];
for(const p of PLACES){const b=document.createElement('button');b.className='landmark-label';b.textContent=p.short;b.setAttribute('aria-label',`Рассмотреть: ${p.title}`);b.onclick=()=>showPlace(p.id);$('labels').appendChild(b);const [x,z]=GEOGRAPHY.landmarks[p.id].point;labelObjects.push({el:b,point:new THREE.Vector3(x,p.height+2,z),id:p.id,street:p.height<3});}
const streetPositions=[{name:'ИВАНОВСКАЯ УЛИЦА',p:[-235,1,-118]},{name:'МОСКОВСКАЯ УЛИЦА',p:[-345,1,42]},{name:'ДВОРЯНСКАЯ УЛИЦА',p:[-265,1,183]}];
for(const s of streetPositions){const el=document.createElement('div');el.className='street-label';el.textContent=s.name;$('labels').appendChild(el);labelObjects.push({el,point:new THREE.Vector3(...s.p),street:true});}

function flyTo(position,target,duration=1.5,zoom=camera.zoom){
  flight={zoomFrom:camera.zoom,zoomTo:zoom,start:performance.now(),duration:duration*1000,from:camera.position.clone(),to:position.clone(),targetFrom:controls.target.clone(),targetTo:target.clone()};controls.enabled=false;
}
function home(){closeDetail();setView('iso');const target=new THREE.Vector3(-40,0,-30);flyTo(target.clone().addScaledVector(ISO_DIRECTION,1350),target,1.2,mobile()?.65:1);}
function configureControls(mode,target){
  controls?.dispose();controls=new OrbitControls(camera,renderer.domElement);
  controls.target.copy(target);controls.enableDamping=true;controls.dampingFactor=.075;
  controls.minDistance=24;controls.maxDistance=1900;controls.minZoom=.35;controls.maxZoom=30;
  controls.screenSpacePanning=false;controls.zoomSpeed=.8;controls.rotateSpeed=.6;
  const fixed=mode==='iso'||mode==='plan';controls.enableRotate=!fixed;controls.enabled=mode!=='walk';
  controls.minPolarAngle=mode==='iso'?Math.acos(1/Math.sqrt(3)):0;
  controls.maxPolarAngle=mode==='iso'?controls.minPolarAngle:mode==='plan'?.00001:Math.PI/2-.05;
  controls.mouseButtons.LEFT=fixed?THREE.MOUSE.PAN:THREE.MOUSE.ROTATE;
  controls.touches.ONE=fixed?THREE.TOUCH.PAN:THREE.TOUCH.ROTATE;
  controls.addEventListener('start',()=>stopTour());
}
function viewRect(){return sceneRect(innerWidth,innerHeight,state.comparison);}
function sceneWidth(){return viewRect().width;}
function resizeScene(){if(!renderer)return;const r=viewRect();resizeCamera(camera,r.width/r.height);renderer.setSize(innerWidth,innerHeight);}

function stopTour(){state.tour=false;$('tour-button').innerHTML='<span>▷</span> Облёт города';}
function safePoint(x,z){
  if(!city.collide(x,z))return [x,z];
  for(let radius=2;radius<65;radius+=2)for(let i=0;i<16;i++){const xx=x+Math.cos(i*Math.PI/8)*radius,zz=z+Math.sin(i*Math.PI/8)*radius;if(!city.collide(xx,zz))return [xx,zz];}
  return [120,-17];
}
function setView(mode,place=null){
  if(!camera)return;stopTour();flight=null;state.view=mode;
  const target=controls.target.clone(),position=camera.position.clone();
  const rect=viewRect();camera=makeCamera(mode,rect.width/rect.height);camera.position.copy(position);configureControls(mode,target);
  document.body.classList.toggle('walk',mode==='walk');
  document.querySelectorAll('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===mode);b.setAttribute('aria-pressed',String(b.dataset.view===mode));});
  $('walk-hint').hidden=mode!=='walk';$('walk-controls').hidden=mode!=='walk';
  if(mode==='walk'){
    const p=place||PLACES.find(p=>p.id===state.selection)||PLACES.find(p=>p.id==='moskovskaya');
    const [x,z]=GEOGRAPHY.landmarks[p.id].point,ap=p.approach||[-40,35],safe=safePoint(x+ap[0],z+ap[1]);camera.position.set(safe[0],1.72,safe[1]);
    yaw=Math.atan2(-(x-safe[0]),-(z-safe[1]));pitch=p.height>20?.12:.02;updateLook();
  }else if(mode==='iso'||mode==='plan'){
    const dir=mode==='iso'?ISO_DIRECTION:new THREE.Vector3(0,1,.00001);
    camera.position.copy(target).addScaledVector(dir,1350);camera.zoom=state.selection?5:mobile()?.65:1;camera.updateProjectionMatrix();camera.lookAt(target);controls.update();
  }else {
    if(camera.position.y<8||position.y>900)camera.position.copy(target).add(new THREE.Vector3(-150,140,190));
    camera.lookAt(target);controls.update();
  }
}

function updateLook(){camera.rotation.order='YXZ';camera.rotation.y=yaw;camera.rotation.x=pitch;camera.rotation.z=0;}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view));
$('reset').onclick=()=>home();
$('zoom-in').onclick=()=>zoom(.78);$('zoom-out').onclick=()=>zoom(1.28);
function zoom(factor){if(!camera)return;if(camera.isOrthographicCamera){stopTour();flight=null;controls.enabled=true;camera.zoom=THREE.MathUtils.clamp(camera.zoom/factor,.35,30);camera.updateProjectionMatrix();return;}if(state.view==='walk'){camera.fov=THREE.MathUtils.clamp(camera.fov*factor,38,84);camera.updateProjectionMatrix();return;}stopTour();flight=null;controls.enabled=true;const offset=camera.position.clone().sub(controls.target);offset.multiplyScalar(factor);offset.clampLength(controls.minDistance,controls.maxDistance);camera.position.copy(controls.target).add(offset);controls.update();}
$('labels-toggle').onclick=()=>{state.labels=!state.labels;$('labels-toggle').setAttribute('aria-pressed',String(state.labels));};
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if($('app').requestFullscreen)await $('app').requestFullscreen();}catch{}};
function updateLifeButton(){$('life-toggle').textContent=state.life?'Движение включено':'Движение на паузе';$('life-toggle').setAttribute('aria-pressed',String(state.life));}
$('life-toggle').onclick=()=>{state.life=!state.life;updateLifeButton();};updateLifeButton();
$('tour-button').onclick=()=>{if(state.tour){stopTour();return;}setView('orbit');closeDetail();state.tour=true;state.tourStart=elapsed;$('tour-button').innerHTML='<span>Ⅱ</span> Остановить';};

function pointerDown(e){if(!camera)return;if(state.view!=='walk'&&e.button>0)return;stopTour();if(flight){flight=null;controls.enabled=state.view!=='walk';}pointer.down=true;pointer.id=e.pointerId;pointer.x=e.clientX;pointer.y=e.clientY;pointer.moved=0;if(state.view==='walk')viewport.setPointerCapture(e.pointerId);viewport.focus({preventScroll:true});}
function pointerMove(e){if(!pointer.down||e.pointerId!==pointer.id)return;const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;pointer.x=e.clientX;pointer.y=e.clientY;pointer.moved+=Math.abs(dx)+Math.abs(dy);if(state.view==='walk'){yaw-=dx*.004;pitch=THREE.MathUtils.clamp(pitch-dy*.003,-1.15,1.15);updateLook();}}
const raycaster=new THREE.Raycaster(),hitPoint=new THREE.Vector3();
function pointerUp(e){if(!pointer.down)return;pointer.down=false;if(state.view==='walk'&&viewport.hasPointerCapture(e.pointerId))viewport.releasePointerCapture(e.pointerId);if(pointer.moved<6){const rect=viewRect(),top=innerHeight-rect.y-rect.height;if(e.clientX>rect.width||e.clientY<top||e.clientY>top+rect.height)return;raycaster.setFromCamera(new THREE.Vector2(e.clientX/rect.width*2-1,-(e.clientY-top)/rect.height*2+1),camera);if(state.measuring){addMeasurement(raycaster.ray);return;}let nearest=null,dist=Infinity;for(const [id,box] of Object.entries(city.landmarkBounds)){const point=raycaster.ray.intersectBox(box,hitPoint);if(point){const dd=point.distanceTo(camera.position);if(dd<dist){dist=dd;nearest=id;}}}if(nearest)showPlace(nearest,state.view!=='walk');}}
viewport.addEventListener('pointerdown',pointerDown);viewport.addEventListener('pointermove',pointerMove);viewport.addEventListener('pointerup',pointerUp);viewport.addEventListener('pointercancel',()=>pointer.down=false);
const keyNames={KeyW:'forward',ArrowUp:'forward',KeyS:'back',ArrowDown:'back',KeyA:'left',ArrowLeft:'left',KeyD:'right',ArrowRight:'right',ShiftLeft:'fast',ShiftRight:'fast'};
window.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]')||/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;if(e.code==='Escape'){closeDetail();return;}if(keyNames[e.code]&&state.view==='walk'){e.preventDefault();keys.add(keyNames[e.code]);}});
window.addEventListener('keyup',e=>{if(keyNames[e.code])keys.delete(keyNames[e.code]);});window.addEventListener('blur',()=>{keys.clear();pointer.down=false;});document.addEventListener('visibilitychange',()=>keys.clear());
document.querySelectorAll('[data-move]').forEach(b=>{b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);keys.add(b.dataset.move);});for(const event of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,()=>keys.delete(b.dataset.move));});

const projection=new THREE.Vector3(),forward=new THREE.Vector3(),ndc=new THREE.Vector3();
function positionLabels(){
  const rect=viewRect(),w=rect.width,h=rect.height,top=innerHeight-rect.y-h,occupied=[];camera.getWorldDirection(forward);
  for(const label of [...labelObjects].sort((a,b)=>Number(b.id===state.selection)-Number(a.id===state.selection))){
    const distance=camera.position.distanceTo(label.point),p=projection.copy(label.point).project(camera);
    const behind=ndc.copy(label.point).sub(camera.position).dot(forward)<0;
    let visible=state.labels&&!state.measuring&&!behind&&p.z<1&&p.z>-1&&Math.abs(p.x)<.95&&p.y>-.80&&p.y<.72;
    if(state.view==='walk'&&(distance>250||label.street))visible=false;
    if(label.street&&(camera.position.y<85||mobile()))visible=false;
    const x=(p.x*.5+.5)*w,y=top+(-p.y*.5+.5)*h;
    const halfWidth=Math.max(55,label.el.textContent.length*3.8+12);
    if(visible&&(x-halfWidth<8||x+halfWidth>w-8||occupied.some(o=>Math.abs(o.x-x)<o.halfWidth+halfWidth+8&&Math.abs(o.y-y)<32)))visible=false;
    label.el.style.display=visible?'':'none';if(!visible)continue;occupied.push({x,y,halfWidth});label.el.style.left=`${Math.round(x)}px`;label.el.style.top=`${Math.round(y)}px`;label.el.classList.toggle('selected',label.id===state.selection);
  }
  const a=state.view==='walk'?yaw:controls.getAzimuthalAngle();$('compass-needle').style.transform=`rotate(${-a}rad)`;
  const dist=state.view==='walk'?camera.position.y:camera.position.distanceTo(controls.target);const metres=metresPerPixel(camera,h,controls.target)*(mobile()?40:60);$('scale').textContent=state.view==='walk'?'Уровень улицы':`${Math.max(1,Math.round(metres))} м`;
}
function walk(dt){
  const f=Number(keys.has('forward'))-Number(keys.has('back')),s=Number(keys.has('right'))-Number(keys.has('left'));if(!f&&!s)return;
  const norm=Math.hypot(f,s),speed=(keys.has('fast')?12:4)*dt/norm;
  const dx=(-Math.sin(yaw)*f+Math.cos(yaw)*s)*speed,dz=(-Math.cos(yaw)*f-Math.sin(yaw)*s)*speed;
  const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.4));for(let i=0;i<steps;i++){if(!city.collide(camera.position.x+dx/steps,camera.position.z))camera.position.x+=dx/steps;if(!city.collide(camera.position.x,camera.position.z+dz/steps))camera.position.z+=dz/steps;}
  camera.position.y=1.72+Math.sin(elapsed*8)*.035;
}
let sunlight,ambient;
function setSun(){
  const value=Number($('sun').value);$('sun-value').textContent=`${String(Math.floor(value)).padStart(2,'0')}:${String(Math.round(value%1*60)).padStart(2,'0')}`;
  if(!sunlight)return;
  const phase=(value-6)/15*Math.PI,alt=Math.max(.10,Math.sin(phase)),warmth=Math.max(0,1-alt),{dusk}=eveningState(value);
  sunlight.userData.sunOffset=new THREE.Vector3(Math.cos(phase)*850,alt*800,-320);
  sunlight.intensity=THREE.MathUtils.lerp(2.1*alt+.65,.055,dusk);
  sunlight.color.setRGB(1,.98-warmth*.23,.89-warmth*.28).lerp(new THREE.Color('#8ea9c9'),dusk);
  ambient.intensity=THREE.MathUtils.lerp(.9+alt*.4,.14,dusk);
  scene.environmentIntensity=THREE.MathUtils.lerp(.26,.025,dusk);
  scene.background.setRGB(.72+warmth*.08,.81-warmth*.03,.84-warmth*.12).lerp(new THREE.Color('#202f45'),dusk);
  scene.fog.color.copy(scene.background);city.setTime(value);
  fitSunShadow(sunlight,camera,controls.target,state.view,true);renderer.shadowMap.needsUpdate=true;
}
$('sun').addEventListener('input',setSun);
let nextVisibility=0;
function animate(now){
  const dt=Math.min(.04,(now-previous)/1000);previous=now;if(document.hidden)return;elapsed+=dt;
  const modal=!!document.querySelector('dialog[open]');
  if(flight){
    const t=THREE.MathUtils.clamp((now-flight.start)/flight.duration,0,1),k=t*t*(3-2*t);camera.position.lerpVectors(flight.from,flight.to,k);controls.target.lerpVectors(flight.targetFrom,flight.targetTo,k);camera.lookAt(controls.target);camera.zoom=THREE.MathUtils.lerp(flight.zoomFrom,flight.zoomTo,k);camera.updateProjectionMatrix();if(t===1){flight=null;controls.enabled=state.view!=='walk';controls.update();}
  }else if(state.tour&&!modal){
    const t=(elapsed-state.tourStart)*.075;controls.target.set(10,8,-15);camera.position.set(10+Math.cos(t+.7)*590,275+Math.sin(t*.7)*45,-15+Math.sin(t+.7)*530);camera.lookAt(controls.target);
  }else if(state.view==='walk'){if(!modal)walk(dt);updateLook();}else controls.update();
  city.update(dt,elapsed,state.life&&!modal);if(now>nextVisibility){const changed=city.updateVisibility(camera);if(renderer.shadowMap.enabled&&(fitSunShadow(sunlight,camera,controls.target,state.view)||changed))renderer.shadowMap.needsUpdate=true;nextVisibility=now+180;}positionLabels();
  const rect=viewRect();renderer.setScissorTest(false);renderer.setClearColor(scene.background);renderer.clear();renderer.setViewport(rect.x,rect.y,rect.width,rect.height);renderer.setScissor(rect.x,rect.y,rect.width,rect.height);renderer.setScissorTest(state.comparison);renderer.render(scene,camera);
}
async function init(){
  try{
    renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,mobile()?1.5:1.8));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.13;renderer.outputColorSpace=THREE.SRGBColorSpace;viewport.appendChild(renderer.domElement);
    renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();$('error').hidden=false;$('error-message').textContent='Браузер остановил 3D-отрисовку. Перезагрузите сцену.';renderer.setAnimationLoop(null);});
    scene=new THREE.Scene();scene.background=new THREE.Color('#b6cfd4');scene.fog=new THREE.Fog('#b6cfd4',1100,2800);scene.environment=createSkyEnvironment();scene.environmentIntensity=.26;
    camera=makeCamera('iso',innerWidth/innerHeight);const target=new THREE.Vector3(-40,0,-30);camera.position.copy(target).addScaledVector(ISO_DIRECTION,1350);camera.zoom=mobile()?.65:1;camera.updateProjectionMatrix();configureControls('iso',target);controls.update();
    ambient=new THREE.HemisphereLight('#e0ecf1','#838567',1.3);scene.add(ambient);sunlight=new THREE.DirectionalLight('#fff4d5',2.3);sunlight.position.set(-420,600,-300);sunlight.castShadow=true;sunlight.shadow.mapSize.set(mobile()?2048:4096,mobile()?2048:4096);scene.add(sunlight,sunlight.target);
    await new Promise(resolve=>requestAnimationFrame(resolve));city=buildCity(scene);const texturesLoaded=await city.loadMaterials();applyQuality(state.quality);setSun();city.update(0,0,false);$('loading').hidden=true;if(!texturesLoaded)notice('Часть текстур не загрузилась. Обновите страницу, чтобы загрузить материалы зданий.');

    window.addEventListener('resize',resizeScene);
    renderer.setAnimationLoop(animate);
  }catch(error){console.error(error);$('loading').hidden=true;$('error').hidden=false;$('error-message').textContent='Для сцены требуется WebGL 2. Проверьте поддержку аппаратного ускорения в браузере. Архивные материалы доступны отдельно.';}
}


let noticeTimer;
function notice(text){$('notice').textContent=text;$('notice').hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$('notice').hidden=true,4500);}
function closeComparison(){
  if(!state.comparison)return;state.comparison=false;$('comparison').hidden=true;document.body.classList.remove('comparing');resizeScene();
  if(state.selection)$('detail').hidden=false;
}
function openComparison(p){
  if(state.view==='walk')setView('iso');
  state.comparison=true;stopTour();$('comparison').hidden=false;$('detail').hidden=true;document.body.classList.add('comparing');
  $('compare-content').innerHTML=`<span class="eyebrow">ФОТОГРАФИЯ И МОДЕЛЬ</span><h2>${p.title}</h2><a href="./assets/${p.photo}" target="_blank" rel="noopener"><img src="./assets/${p.photo}" alt="${p.title}: фотографический источник"></a><p>${p.photoCaption||'Фотография сохранившегося здания.'}</p><p class="source"><a href="${p.photoSource||p.source}" target="_blank" rel="noopener">${p.photoCredit||p.sourceName}</a>${p.photoLicense?` · <a href="${p.photoLicenseUrl}" target="_blank" rel="noopener">${p.photoLicense}</a>`:''}</p><div class="evidence-facts"><strong>Что сопоставлять</strong><p>${evidenceFor(p).known}</p><strong>Границы достоверности</strong><p>${evidenceFor(p).inferred}</p></div><p class="tool-note">Модель можно приближать и перемещать. В режиме «Обзор» — поворачивать. Современное фото не подтверждает цвет здания в 1910 году.</p>`;
  resizeScene();const [x,z]=GEOGRAPHY.landmarks[p.id].point,target=new THREE.Vector3(x,p.height*.3,z);
  if(p.id==='inn'){
    const choices=document.createElement('div');choices.className='detail-actions';
    choices.innerHTML='<button data-model-angle="orbit">Фасад</button><button data-model-angle="iso">Изометрия</button>';
    $('compare-content').querySelector('h2').after(choices);
    const focus=mode=>{
      setView(mode);const target=new THREE.Vector3(x,p.height*.38,z+4),rect=viewRect();
      if(mode==='iso')flyTo(target.clone().addScaledVector(ISO_DIRECTION,1050),target,1,camera.userData.span/(mobile()?42:57));
      else {
        const distance=Math.max(34,24/(Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*(rect.width/rect.height)));
        flyTo(new THREE.Vector3(x+Math.sin(.37)*distance,Math.max(14,distance*.28),z+8.65+Math.cos(.37)*distance),new THREE.Vector3(x,5.5,z+8.65),1);
      }
      choices.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.modelAngle===mode)));
    };
    choices.querySelectorAll('button').forEach(b=>b.onclick=()=>focus(b.dataset.modelAngle));focus('orbit');return;
  }
  if(camera.isOrthographicCamera){const dir=state.view==='plan'?new THREE.Vector3(0,1,.00001):ISO_DIRECTION;flyTo(target.clone().addScaledVector(dir,1050),target,1,camera.userData.span/(mobile()?180:145));}
  else flyTo(target.clone().add(new THREE.Vector3(-85,65,95)),target,1);
}
$('compare-close').onclick=closeComparison;
function applyQuality(value){
  state.quality=value;$('quality').value=value;if(!renderer||!city)return;
  const presets={low:{ratio:1,shadow:0},balanced:{ratio:1.5,shadow:2048},high:{ratio:2,shadow:4096}},p=presets[value]||presets.balanced;
  renderer.setPixelRatio(Math.min(devicePixelRatio,p.ratio));renderer.shadowMap.enabled=!!p.shadow;
  renderer.shadowMap.autoUpdate=value==='high';
  if(p.shadow&&sunlight.shadow.mapSize.x!==p.shadow){sunlight.shadow.map?.dispose();sunlight.shadow.map=null;sunlight.shadow.mapSize.set(p.shadow,p.shadow);}
  city.layers.residents.traverse(o=>{if(o.isMesh)o.castShadow=value==='high';});
  renderer.shadowMap.needsUpdate=true;city.setQuality(value,renderer.capabilities.getMaxAnisotropy());city.updateVisibility(camera);fitSunShadow(sunlight,camera,controls.target,state.view,true);resizeScene();
}
$('quality').onchange=e=>applyQuality(e.target.value);
document.querySelectorAll('[data-layer]').forEach(input=>input.onchange=()=>{
  if(!city)return;const key=input.dataset.layer;
  if(key==='ordinary'){city.background.visible=input.checked;state.evidence=!input.checked;}
  else city.layers[key].visible=input.checked;
  renderer.shadowMap.needsUpdate=true;
});
let measurementGroup=null,measurementPoints=[];
function resetMeasurement(){measurementGroup?.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});if(measurementGroup)scene.remove(measurementGroup);measurementGroup=null;measurementPoints=[];}
function toggleMeasurement(){
  if(!scene)return;state.measuring=!state.measuring;$('measure-button').setAttribute('aria-pressed',String(state.measuring));
  $('measure-button').textContent=state.measuring?'Закончить измерение':'Измерить расстояние';$('measure-readout').hidden=!state.measuring;
  if(state.measuring){closeDetail();stopTour();$('scene-tools').open=false;resetMeasurement();$('measure-readout').textContent='Выберите две точки на земле · расстояние по прямой';}
  else resetMeasurement();
}
$('measure-button').onclick=toggleMeasurement;
function addMeasurement(ray){
  const hit=ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0),-.12),new THREE.Vector3());
  if(!hit||hit.x<GEOGRAPHY.bounds[0]||hit.x>GEOGRAPHY.bounds[1]||hit.z<GEOGRAPHY.bounds[2]||hit.z>GEOGRAPHY.bounds[3]){notice('Выберите точку внутри реконструированного города.');return;}
  if(measurementPoints.length===2)resetMeasurement();
  if(!measurementGroup){measurementGroup=new THREE.Group();scene.add(measurementGroup);}
  hit.y=.22;measurementPoints.push(hit.clone());
  const marker=new THREE.Mesh(new THREE.SphereGeometry(1.25,12,8),new THREE.MeshBasicMaterial({color:'#b76433',depthTest:false}));marker.position.copy(hit);marker.renderOrder=100;measurementGroup.add(marker);
  if(measurementPoints.length===1){$('measure-readout').textContent='Выберите вторую точку · Esc — закончить';return;}
  const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(measurementPoints),new THREE.LineBasicMaterial({color:'#9c4327',depthTest:false}));line.renderOrder=101;measurementGroup.add(line);
  const distance=measurementPoints[0].distanceTo(measurementPoints[1]);$('measure-readout').textContent=`≈ ${Math.round(distance)} м по прямой · следующая точка начнёт новое измерение · Esc — закончить`;
}
window.addEventListener('keydown',e=>{if(e.code==='Escape'&&state.measuring)toggleMeasurement();});
const viewKey='pokrov-viewpoints-v1';
let savedViews=[];
try{const v=JSON.parse(localStorage.getItem(viewKey)||'[]');if(Array.isArray(v))savedViews=v.filter(x=>['iso','orbit','walk','plan'].includes(x.mode)&&[x.position,x.target].every(a=>Array.isArray(a)&&a.length===3&&a.every(n=>Number.isFinite(n)&&Math.abs(n)<5000))).slice(0,6);}catch{}
function persistViews(){try{localStorage.setItem(viewKey,JSON.stringify(savedViews));return true;}catch{notice('Браузер не разрешил сохранение ракурсов. Они доступны до закрытия страницы.');return false;}}
function drawViews(){
  $('saved-views').replaceChildren();
  savedViews.forEach((view,index)=>{
    const row=document.createElement('div');row.className='saved-view';
    const load=document.createElement('button');load.textContent=view.name;load.onclick=()=>{
      closeDetail();setView(view.mode);flight=null;camera.position.fromArray(view.position);controls.target.fromArray(view.target);
      camera.zoom=THREE.MathUtils.clamp(Number(view.zoom)||1,.35,30);camera.updateProjectionMatrix();
      if(view.mode==='walk'){const safe=safePoint(camera.position.x,camera.position.z);camera.position.set(safe[0],1.72,safe[1]);yaw=Number(view.yaw)||0;pitch=THREE.MathUtils.clamp(Number(view.pitch)||0,-1.15,1.15);updateLook();}else{camera.lookAt(controls.target);controls.update();}
      $('sun').value=THREE.MathUtils.clamp(Number(view.sun)||16,7,22);setSun();$('scene-tools').open=false;notice('Ракурс восстановлен.');
    };
    const remove=document.createElement('button');remove.textContent='×';remove.setAttribute('aria-label','Удалить ракурс');remove.onclick=()=>{savedViews.splice(index,1);persistViews();drawViews();};row.append(load,remove);$('saved-views').append(row);
  });
}
$('save-view').onclick=()=>{
  if(!camera)return;const p=PLACES.find(p=>p.id===state.selection),mode={iso:'Изометрия',plan:'План',walk:'Прогулка',orbit:'Обзор'}[state.view];
  savedViews.unshift({name:p?`${p.short} · ${mode}`:`${mode} · ${savedViews.length+1}`,mode:state.view,position:camera.position.toArray(),target:controls.target.toArray(),zoom:camera.zoom,yaw,pitch,sun:Number($('sun').value)});
  savedViews=savedViews.slice(0,6);const persisted=persistViews();drawViews();if(persisted)notice('Ракурс сохранён в этом браузере.');
};
drawViews();
init();
