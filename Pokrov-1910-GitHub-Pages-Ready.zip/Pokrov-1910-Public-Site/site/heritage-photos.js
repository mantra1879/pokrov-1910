export const HERITAGE_PHOTOS = [
  {
    "id": "male",
    "file": "male-gymnasium.jpg",
    "title": "Мужская гимназия",
    "caption": "Современный вид, 2022 год. Мужская гимназия — улица III Интернационала, 52, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BC%D1%83%D0%B6%D1%81%D0%BA%D0%BE%D0%B9_%D0%B3%D0%B8%D0%BC%D0%BD%D0%B0%D0%B7%D0%B8%D0%B8,_III_%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%B0%D0%BB%D0%B0,_52.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "female",
    "file": "female-gymnasium.jpg",
    "title": "Женская гимназия",
    "caption": "Современный вид, 2016 год. Женская гимназия — улица Ленина, 107, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%93%D0%B8%D0%BC%D0%BD%D0%B0%D0%B7%D0%B8%D1%8F_%D0%B6%D0%B5%D0%BD%D1%81%D0%BA%D0%B0%D1%8F,_%D0%BA%D0%BE%D0%BD.XIX_%D0%B2.jpg",
    "credit": "Viktor Sagaydashin",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "civic",
    "file": "civic-offices.jpg",
    "title": "Присутственные места / городская администрация",
    "caption": "Современный вид, 2022 год. Присутственные места / городская администрация — Советская улица, 42, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5_%D0%B6%D0%B5%D0%BD%D1%81%D0%BA%D0%BE%D0%B9_%D0%B3%D0%B8%D0%BC%D0%BD%D0%B0%D0%B7%D0%B8%D0%B8,_%D0%A1%D0%BE%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B0%D1%8F,_42.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "hospital",
    "file": "zemstvo-hospital.jpg",
    "title": "Земская больница",
    "caption": "Современный вид, 2023 год. Земская больница — улица III Интернационала, 48, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D0%B7%D0%B5%D0%BC%D1%81%D0%BA%D0%B0%D1%8F_%D0%B1%D0%BE%D0%BB%D1%8C%D0%BD%D0%B8%D1%86%D0%B0,_3_%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%B0%D0%BB%D0%B0,_48.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "administrative",
    "file": "administrative-lenina81.jpg",
    "title": "Административное здание",
    "caption": "Современный вид, 2023 год. Административное здание — улица Ленина, 81, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D0%B0%D0%B4%D0%BC%D0%B8%D0%BD%D0%B8%D1%81%D1%82%D1%80%D0%B0%D1%82%D0%B8%D0%B2%D0%BD%D0%BE%D0%B5_%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5,_%D0%9B%D0%B5%D0%BD%D0%B8%D0%BD%D0%B0,_81.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "treasury",
    "file": "treasury.jpg",
    "title": "Бывшее казначейство",
    "caption": "Современный вид, 2023 год. Бывшее казначейство — Советская улица, 40, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%97%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5_%D0%B1%D1%8B%D0%B2%D1%88%D0%B5%D0%B3%D0%BE_%D0%BA%D0%B0%D0%B7%D0%BD%D0%B0%D1%87%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D0%B0.jpg",
    "credit": "Чуринъ",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "annex",
    "file": "annex.jpg",
    "title": "Жилой флигель",
    "caption": "Современный вид, 2022 год. Жилой флигель — Советская улица, 44, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D1%84%D0%BB%D0%B8%D0%B3%D0%B5%D0%BB%D1%8C_%D0%B6%D0%B5%D0%BD%D1%81%D0%BA%D0%BE%D0%B9_%D0%B3%D0%B8%D0%BC%D0%BD%D0%B0%D0%B7%D0%B8%D0%B8,_%D0%A1%D0%BE%D0%B2%D0%B5%D1%82%D1%81%D0%BA%D0%B0%D1%8F,_44.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "cheburov",
    "file": "cheburov-house.jpg",
    "title": "Дом ямщиков Чебуровых",
    "caption": "Современный вид, 2023 год. Дом ямщиков Чебуровых — улица Ленина, 118, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D0%B4%D0%BE%D0%BC_%D1%8F%D0%BC%D1%89%D0%B8%D0%BA%D0%B0_%D0%A7%D0%B5%D0%B1%D1%83%D1%80%D0%BE%D0%B2%D0%B0,_%D0%9B%D0%B5%D0%BD%D0%B8%D0%BD%D0%B0,_118.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "inn",
    "file": "inn-kornilova-lenina94.jpg",
    "title": "Доходный дом Корниловой",
    "caption": "Современный вид, 2023 год. Доходный дом Корниловой — улица Ленина, 94, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:%D0%9F%D0%BE%D0%BA%D1%80%D0%BE%D0%B2,_%D0%B4%D0%BE%D1%85%D0%BE%D0%B4%D0%BD%D1%8B%D0%B9_%D0%B4%D0%BE%D0%BC_%D0%9A%D0%BE%D1%80%D0%BD%D0%B8%D0%BB%D0%BE%D0%B2%D0%BE%D0%B9,_%D0%9B%D0%B5%D0%BD%D0%B8%D0%BD%D0%B0,_94.jpg",
    "credit": "Константин Лосевский",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  },
  {
    "id": "police",
    "file": "museum-lenina79.jpg",
    "title": "Полицейская часть / краеведческий музей",
    "caption": "Современный вид, 2013 год. Полицейская часть / краеведческий музей — улица Ленина, 79, Покров, Владимирская область.",
    "url": "https://commons.wikimedia.org/wiki/File:History_Museum_of_Pokrov._summer_2013.jpg",
    "credit": "Macs24",
    "license": "CC BY-SA 3.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/3.0",
    "changes": "Размер уменьшен для просмотра; содержание фотографии не изменено."
  }
];
