import * as THREE from './assets/three.module.js';

// Base-colour images are artistic material references, not historical façades.
// Dimensions below are in metres; mesh size never stretches the brick courses.
export function createArchitecturalMaterials(palette){
  const textures=[],materials=[],pending=[];
  function configure(texture,mirror=false){
    texture.wrapS=texture.wrapT=mirror?THREE.MirroredRepeatWrapping:THREE.RepeatWrapping;
    texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;
    texture.generateMipmaps=true;texture.anisotropy=4;textures.push(texture);return texture;
  }
  function imageTexture(file){
    const fallback=document.createElement('canvas');fallback.width=fallback.height=1;const ctx=fallback.getContext('2d');ctx.fillStyle=file.startsWith('brick')?'#ad6b4f':'#96816a';ctx.fillRect(0,0,1,1);
    const t=configure(new THREE.Texture(fallback),true);t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;
    pending.push(()=>new Promise(resolve=>new THREE.ImageLoader().load(new URL('./assets/materials/'+file,import.meta.url).href,img=>{t.image=img;t.needsUpdate=true;resolve(true);},undefined,()=>resolve(false))));
    return t;
  }
  function dataTexture(width,height,sample,color=false){
    const data=new Uint8Array(width*height*4);
    for(let y=0;y<height;y++)for(let x=0;x<width;x++){
      const rgb=sample(x/width,y/height,x,y),offset=(y*width+x)*4;
      for(let i=0;i<3;i++)data[offset+i]=Math.round(THREE.MathUtils.clamp(Array.isArray(rgb)?rgb[i]:rgb,0,1)*255);
      data[offset+3]=255;
    }
    const t=configure(new THREE.DataTexture(data,width,height,THREE.RGBAFormat));
    if(color)t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;return t;
  }
  const noise=(x,y)=>{const n=Math.sin(x*127.1+y*311.7)*43758.5453;return n-Math.floor(n);};
  const brick=imageTexture('brick-albedo.webp'),wood=imageTexture('timber-albedo.webp');
  const plaster=dataTexture(256,256,(u,v,x,y)=>.94+noise(x,y)*.06,true);
  const plasterBump=dataTexture(256,256,(u,v,x,y)=>.35+noise(x,y)*.3);
  // A standing-seam sheet: a 58 cm pan, 2.4 m transverse lap, centimetre relief.
  const edge=u=>Math.min(u,1-u),seam=u=>Math.exp(-Math.pow(edge(u)/.018,2));
  const metal=dataTexture(256,256,(u,v,x,y)=>.91+.055*noise(x,y)-.085*seam(u)-.035*Math.exp(-Math.pow(edge(v)/.006,2)),true);
  const metalBump=dataTexture(256,256,(u,v)=>.22+.64*seam(u)+.10*Math.exp(-Math.pow(edge(v)/.009,2)));
  const metalRough=dataTexture(256,256,(u,v,x,y)=>.87+.08*noise(x,y)+.04*seam(u));
  function finish(material,kind='plaster'){
    const surface={kind,width:1.6,height:1.6};
    if(kind==='brick'){
      material.map=brick;material.bumpMap=brick;material.bumpScale=-.018;
      material.color.set('#fff4eb');material.roughness=.91;surface.width=2.05;surface.height=1.925;
    }else if(kind==='wood'||kind==='door'){
      material.map=wood;material.bumpMap=wood;material.bumpScale=.012;material.roughness=.9;
      surface.width=2.4;surface.height=1.6;
    }else if(kind==='roof'){
      material.map=metal;material.bumpMap=metalBump;material.bumpScale=.025;
      material.roughnessMap=metalRough;material.roughness=.76;material.metalness=.24;
      surface.width=.58;surface.height=2.4;
    }else {
      material.map=plaster;material.bumpMap=plasterBump;material.bumpScale=.007;material.roughness=.94;
    }
    material.userData.surface=surface;material.userData.fullBumpMap=material.bumpMap;
    if(kind==='plaster'||kind==='brick'){
      const strength=kind==='brick'?.045:.095;
      material.onBeforeCompile=shader=>{
        shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vFacadePosition;').replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nvFacadePosition = (modelMatrix * vec4(transformed, 1.0)).xyz;');
        shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vFacadePosition;').replace('#include <color_fragment>',`#include <color_fragment>
          float baseWear = (1.0-smoothstep(0.35,1.55,vFacadePosition.y))*${strength.toFixed(3)};
          float broadTone = 0.012*(sin(vFacadePosition.x*0.41+vFacadePosition.z*0.37)*0.5+0.5);
          diffuseColor.rgb *= vec3(1.0-baseWear-broadTone,1.0-baseWear*1.06-broadTone,1.0-baseWear*1.16-broadTone);`);
      };
      material.customProgramCacheKey=()=>`pokrov-facade-v1-${kind}`;
    }
    materials.push(material);return material;
  }
  for(const name of ['chalk','plaster','ivory','white','ochre','blue'])finish(palette[name]);
  for(const name of ['brick','brick2'])finish(palette[name],'brick');
  palette.brick.color.set('#d3c3b7');palette.brick2.color.set('#eddac8');
  for(const [name,tint] of Object.entries({wood:'#f2e5d1',darkwood:'#bbb0a0',timber:'#ffefda',weathered:'#dddccf',door:'#aaa895'})){
    palette[name].color.set(tint);finish(palette[name],name==='door'?'door':'wood');
  }
  for(const name of ['roof','roof2','roof3'])finish(palette[name],'roof');
  palette.reveal=new THREE.MeshStandardMaterial({color:'#796d59',roughness:.97});
  palette.glass.metalness=.08;palette.glass.roughness=.25;palette.glass.envMapIntensity=.65;
  palette.windowGlass=['#34474a','#3d5152','#4b5b56','#39484d'].map(color=>new THREE.MeshStandardMaterial({color,roughness:.23,metalness:.08,envMapIntensity:.7}));
  return {
    finish,
    load:()=>Promise.all(pending.map(load=>load())).then(results=>results.every(Boolean)),
    setQuality(value,maxAnisotropy=4){
      for(const texture of textures){texture.anisotropy=Math.min(maxAnisotropy,value==='high'?8:value==='low'?2:4);texture.needsUpdate=true;}
      for(const material of materials){const bump=value==='low'?null:material.userData.fullBumpMap;if(material.bumpMap!==bump){material.bumpMap=bump;material.needsUpdate=true;}}
    }
  };
}

// Triangles are already transformed into the common metre-based city frame.
export function mapArchitecturalUV(geometry,material,{x=0,z=0,angle=0,cylinderLength=0,cylinderRadius=0,uvOffset=[0,0]}={}){
  const surface=material.userData.surface;if(!surface)return;
  const positions=geometry.attributes.position,normals=geometry.attributes.normal,old=geometry.attributes.uv;
  const uv=new Float32Array(positions.count*2),c=Math.cos(angle),s=Math.sin(angle);
  if(cylinderLength&&(surface.kind==='wood'||surface.kind==='door')&&old){
    for(let i=0;i<positions.count;i++){uv[i*2]=old.getY(i)*cylinderLength/surface.width+uvOffset[0];uv[i*2+1]=old.getX(i)*Math.PI*2*cylinderRadius/surface.height+uvOffset[1];}
  }else for(let i=0;i<positions.count;i+=3){
    const nx=c*normals.getX(i)-s*normals.getZ(i),ny=normals.getY(i),nz=s*normals.getX(i)+c*normals.getZ(i),horizontal=Math.hypot(nx,nz);
    const tx=horizontal>1e-5?nz/horizontal:1,tz=horizontal>1e-5?-nx/horizontal:0;
    const down=surface.kind==='roof'&&ny>.02&&horizontal>.02?new THREE.Vector3(nx,-horizontal*horizontal/ny,nz).normalize():null;
    for(let j=i;j<i+3;j++){
      const dx=positions.getX(j)-x,dz=positions.getZ(j)-z,lx=c*dx-s*dz,lz=s*dx+c*dz,y=positions.getY(j);
      let u=lx*tx+lz*tz,v=y;
      if(horizontal<.02){u=lx;v=lz;}
      else if(down)v=lx*down.x+y*down.y+lz*down.z;
      if(surface.kind==='door')[u,v]=[v,u];
      uv[j*2]=u/surface.width;uv[j*2+1]=v/surface.height;
    }
  }
  geometry.setAttribute('uv',new THREE.BufferAttribute(uv,2));
}

export function createSkyEnvironment(){
  const width=128,height=64,data=new Uint8Array(width*height*4);
  const sky=new THREE.Color('#b4cbd7'),horizon=new THREE.Color('#d5d8ca'),ground=new THREE.Color('#787969'),color=new THREE.Color();
  for(let y=0;y<height;y++){
    const t=1-y/(height-1);color.copy(t<.5?sky:horizon).lerp(t<.5?horizon:ground,t<.5?t*2:(t-.5)*2).convertLinearToSRGB();
    for(let x=0;x<width;x++){const i=(y*width+x)*4;data[i]=color.r*255;data[i+1]=color.g*255;data[i+2]=color.b*255;data[i+3]=255;}
  }
  const texture=new THREE.DataTexture(data,width,height,THREE.RGBAFormat);texture.colorSpace=THREE.SRGBColorSpace;texture.mapping=THREE.EquirectangularReflectionMapping;texture.needsUpdate=true;return texture;
}
