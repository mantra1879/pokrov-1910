import * as THREE from './assets/three.module.js';
import { mergeGeometries } from './assets/BufferGeometryUtils.js';
import { GEOGRAPHY } from './geography.js';
import { buildHeritage } from './heritage-models.js';
import { buildSurfaces } from './surfaces.js';
import { buildPokrov } from './pokrov-model.js';
import { buildStreetLife } from './street-life.js';
import { enclosureLayout } from './church-enclosures.js';
import { createArchitecturalMaterials, mapArchitecturalUV } from './architectural-materials.js';
import { createPavingMaterial, buildStreetLighting } from './street-infrastructure.js';
import { buildKornilova } from './kornilova-model.js';

// Coordinates are metres: X east, Z south. Historic façades are interpreted
// from the cited photographs; heights and ordinary parcels are approximate.
export function buildCity(scene) {
  let seed = 1907;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const between = (a,b) => a + rnd()*(b-a);
  const batches = new Map();
  const background = new THREE.Group();
  const established = new THREE.Group();
  scene.add(background, established);
  background.name='ordinary-buildings';established.name='city';
  const layers={fences:new THREE.Group(),vegetation:new THREE.Group(),residents:new THREE.Group()};
  for(const [name,group] of Object.entries(layers)){group.name=name;scene.add(group);}
  const historicModels={},detailMeshes=[];
  let activeBuilding=null,activePart='details',quality='balanced';
  function setBuilding(id){activeBuilding=id;activePart='details';if(id&&!historicModels[id]){
    const group=new THREE.Group();group.name=id;established.add(group);
    const parts={};for(const name of ['foundation','walls','roof','details']){parts[name]=new THREE.Group();parts[name].name=name;group.add(parts[name]);}
    historicModels[id]={group,...parts};
  }}
  function setPart(part){activePart=part;}
  const solids = [], fenceSegments = [], roadSegments = [], landmarkBounds = {};
  const mat = (color, extra={}) => new THREE.MeshStandardMaterial({color,roughness:.88,...extra});
  const palette = {
    chalk:mat('#e6dec3'), plaster:mat('#d9ccb0'), ivory:mat('#eee7d4'), white:mat('#e8e2d3'),
    blue:mat('#b0bdb8'), ochre:mat('#c4ad72'), brick:mat('#986653'), brick2:mat('#a78066'),
    wood:mat('#8c7861'), darkwood:mat('#675242'), timber:mat('#9c8a6b'), weathered:mat('#acaa96'),
    roof:mat('#67716a',{metalness:.2}), roof2:mat('#73847c',{metalness:.15}), roof3:mat('#857d6c'),
    dome:mat('#566d69',{metalness:.35,roughness:.55}), metal:mat('#454b42',{metalness:.4}),
    glass:mat('#3f5557',{roughness:.35,metalness:.35}), door:mat('#4e4a3c'),
    leaf:mat('#667953',{flatShading:true}), leaf2:mat('#829166',{flatShading:true}), leaf3:mat('#556b4a',{flatShading:true}),
    grass:mat('#91a17e'), soil:mat('#a3997a'), garden:mat('#737b53'), stone:mat('#adac95'),
    lantern:mat('#ffe6ad',{emissive:'#f4be66',emissiveIntensity:.2}), iron:mat('#555b51'),
  };
  function materialTexture(kind) {
    const c=document.createElement('canvas');c.width=c.height=256;const ctx=c.getContext('2d');
    if(kind==='stone'){
      ctx.fillStyle='#aaa18b';ctx.fillRect(0,0,256,256);
      for(let y=0;y<16;y++)for(let x=0;x<16;x++){
        const b=Math.floor(between(130,172));ctx.fillStyle=`rgb(${b+10},${b+5},${b-10})`;
        ctx.fillRect((x*17+(y%2)*8)%256,y*17,15+between(-2,1),14+between(-1,2));
      }
    }else{
      ctx.fillStyle='#9eae88';ctx.fillRect(0,0,256,256);
      for(let i=0;i<8000;i++){const b=Math.floor(between(124,162));ctx.fillStyle=`rgba(${b+7},${b+17},${b-16},.16)`;ctx.fillRect(rnd()*256,rnd()*256,between(1,15),between(1,12));}
    }
    const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;return t;
  }
  const groundMat=mat('#b5c4a5',{map:materialTexture('grass')});groundMat.map.repeat.set(25,25);
  // Keep existing plots, trees and actors stable when replacing the old map.
  for(let i=0;i<16*16*3;i++)rnd();
  const pavingMaterials=createPavingMaterial(),cobble=pavingMaterials.material;
  // Preserve the original procedural placement sequence when replacing plaster.
  for(let i=0;i<1800*5;i++)rnd();
  const surfaceMaterials=createArchitecturalMaterials(palette);
  const track=mat('#b9ad90');
  const waterMat=mat('#6e918a',{roughness:.27,metalness:.25});
  const baseGeo=new THREE.PlaneGeometry(3400,2800,1,1);baseGeo.rotateX(-Math.PI/2);
  const ground=new THREE.Mesh(baseGeo,groundMat);ground.position.y=-.25;ground.receiveShadow=true;scene.add(ground);
  const unitBox=new THREE.BoxGeometry(1,1,1);
  const unitCylinder=new THREE.CylinderGeometry(1,1,1,12);
  const unitSphere=new THREE.IcosahedronGeometry(1,1);
  const m4=new THREE.Matrix4(),q=new THREE.Quaternion(),v=new THREE.Vector3(),scale=new THREE.Vector3();
  function push(geo, material, x,y,z,sx=1,sy=1,sz=1,ry=0,category='known',rx=0,rz=0) {
    q.setFromEuler(new THREE.Euler(rx,ry,rz));m4.compose(v.set(x,y,z),q,scale.set(sx,sy,sz));
    let g=geo.clone();if(g.index){const ni=g.toNonIndexed();g.dispose();g=ni;}
    g.applyMatrix4(m4);if(!g.attributes.uv)g.setAttribute('uv',new THREE.Float32BufferAttribute(new Float32Array(g.attributes.position.count*2),2));
    const frame=activeBuilding?GEOGRAPHY.landmarks[activeBuilding]:null;
    mapArchitecturalUV(g,material,{x:frame?.point[0]??x,z:frame?.point[1]??z,angle:frame?.angle??ry,cylinderLength:geo.userData.logLength||(geo===unitCylinder?sy:0),cylinderRadius:geo.userData.logRadius||(geo===unitCylinder?sx:0),uvOffset:geo.userData.logUVOffset});
    g.computeBoundingSphere();const centre=g.boundingSphere.center;
    const building=category==='known'?activeBuilding:null;
    const detail=category==='ordinary'&&(material===palette.glass||material===palette.ivory||material===palette.door);
    const key=`${material.uuid}/${category}/${building||Math.floor(centre.x/160)+','+Math.floor(centre.z/160)}/${building?activePart:detail?'details':'body'}`;
    if(!batches.has(key))batches.set(key,{material,category,building,part:activePart,detail,geometries:[]});
    batches.get(key).geometries.push(g);
  }
  const box=(x,y,z,w,h,d,m,ry=0,cat='known')=>push(unitBox,m,x,y,z,w,h,d,ry,cat);
  const cylinder=(x,y,z,r,h,m,cat='known')=>push(unitCylinder,m,x,y,z,r,h,r,0,cat);
  function local(x,z,angle,lx,lz){return [x+Math.cos(angle)*lx+Math.sin(angle)*lz,z-Math.sin(angle)*lx+Math.cos(angle)*lz];}
  function lbox(x,z,a,lx,y,lz,w,h,d,m,cat='known') {const p=local(x,z,a,lx,lz);box(p[0],y,p[1],w,h,d,m,a,cat);}
  function hippedRoof(x,z,w,d,base,h,material,a=0,cat='known'){
    const previousPart=activePart;if(activeBuilding)activePart='roof';
    const ridge=Math.max(0,(w-d)*.5),ww=w/2,dd=d/2;
    const vertices=[-ww,0,-dd, ww,0,-dd, ridge,h,0, -ww,0,-dd, ridge,h,0, -ridge,h,0,
      ww,0,dd,-ww,0,dd,-ridge,h,0, ww,0,dd,-ridge,h,0,ridge,h,0,
      -ww,0,dd,-ww,0,-dd,-ridge,h,0, ww,0,-dd,ww,0,dd,ridge,h,0];
    for(let i=0;i<vertices.length;i+=9)for(let k=0;k<3;k++){const t=vertices[i+3+k];vertices[i+3+k]=vertices[i+6+k];vertices[i+6+k]=t;}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.computeVertexNormals();
    push(g,material,x,base,z,1,1,1,a,cat);g.dispose();activePart=previousPart;
  }
  function gableRoof(x,z,w,d,base,h,material,a=0,cat='known'){
    const ww=w/2,dd=d/2;
    const pos=[-ww,0,-dd,ww,0,-dd,ww,h,0,-ww,0,-dd,ww,h,0,-ww,h,0,
      ww,0,dd,-ww,0,dd,-ww,h,0,ww,0,dd,-ww,h,0,ww,h,0,
      -ww,0,dd,-ww,0,-dd,-ww,h,0,ww,0,-dd,ww,0,dd,ww,h,0];
    for(let i=0;i<pos.length;i+=9)for(let k=0;k<3;k++){const t=pos[i+3+k];pos[i+3+k]=pos[i+6+k];pos[i+6+k]=t;}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.computeVertexNormals();push(g,material,x,base,z,1,1,1,a,cat);g.dispose();
  }
  function lathe(x,y,z,profile,material,segments=32,cat='known'){
    const g=new THREE.LatheGeometry(profile.map(p=>new THREE.Vector2(...p)),segments);push(g,material,x,y,z,1,1,1,0,cat);g.dispose();
  }
  function cross(x,y,z,size=1,cat='known'){
    box(x,y+size*1.15,z,.17*size,2.6*size,.17*size,palette.metal,0,cat);
    box(x,y+size*1.6,z,1.45*size,.16*size,.16*size,palette.metal,0,cat);
    box(x,y+size*2.2,z,.8*size,.12*size,.14*size,palette.metal,0,cat);
    push(unitBox,palette.metal,x,y+.6*size,z,.9*size,.12*size,.13*size,0,cat,0,0,-.25);
  }
  function onion(x,y,z,r,h,material=palette.dome,cat='known'){
    lathe(x,y,z,[[r*.53,0],[r*.6,h*.13],[r*.96,h*.31],[r,h*.44],[r*.79,h*.61],[r*.42,h*.80],[.06,h]],material,32,cat);
    cross(x,y+h,z,r*.36,cat);
  }
  function arch(x,y,z,w,h,depth,material,a=0,cat='known'){
    const s=new THREE.Shape();s.moveTo(-w/2,0);s.lineTo(w/2,0);s.lineTo(w/2,h-w/2);s.absarc(0,h-w/2,w/2,0,Math.PI,false);s.lineTo(-w/2,0);
    const g=new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:false,curveSegments:8});push(g,material,x,y,z,1,1,1,a,cat);g.dispose();
  }
  function windowAt(x,z,a,lx,lz,y,w,h,cat,arched=false,trim=palette.ivory,recessed=false){
    if(recessed){
      const frame=.13,depth=.12,back=lz-.27;
      for(const side of [-1,1]){
        lbox(x,z,a,lx+side*(w/2+frame/2),y+h/2,lz+.025,frame,h+.26,depth,trim,cat);
        lbox(x,z,a,lx+side*(w/2-.018),y+h/2,lz-.13,.035,h,.30,palette.reveal,cat);
      }
      for(const yy of [y-frame/2,y+h+frame/2])lbox(x,z,a,lx,yy,lz+.025,w+.26,frame,depth,trim,cat);
      lbox(x,z,a,lx,y+h/2,back,w,h,.035,palette.glass,cat);
      const variant=Math.abs(Math.round(x*7+z*13+lx*5+y*3));
      for(let row=0;row<2;row++)for(let col=0;col<2;col++){
        const ph=h*(row?.39:.61)-.06,py=row?y+h*.805:y+h*.305;
        lbox(x,z,a,lx+(col?1:-1)*(w*.25+.015),py,back+.023,w/2-.045,ph,.012,palette.windowGlass[(variant+row+col)%4],cat);
      }
      lbox(x,z,a,lx,y+h/2,lz-.17,.075,h,.09,trim,cat);
      lbox(x,z,a,lx,y+h*.61,lz-.17,w,.075,.09,trim,cat);
      lbox(x,z,a,lx,y-.12,lz-.025,w+.44,.16,.56,trim,cat);
      lbox(x,z,a,lx,y+h+.04,lz-.12,w,.06,.3,palette.reveal,cat);
      return;
    }
    lbox(x,z,a,lx,y+h/2,lz,w+.30,h+.3,.17,trim,cat);
    lbox(x,z,a,lx,y+h/2,lz+.11,w,h,.18,palette.glass,cat);
    lbox(x,z,a,lx,y+h/2,lz+.22,.08,h,.07,trim,cat);
    lbox(x,z,a,lx,y+h*.61,lz+.22,w,.08,.07,trim,cat);
    lbox(x,z,a,lx,y-.13,lz+.16,w+.5,.16,.43,trim,cat);
    if(arched){const p=local(x,z,a,lx,lz+.18);arch(p[0],y+h-.03,p[1],w+.30,.66,.10,trim,a,cat);}
  }
  function building({x,z,w=18,d=12,h=7,angle=.18,color=palette.plaster,roof=palette.roof,floors=2,attic=false,cat='ordinary',sign='',ornate=false}) {
    if(activeBuilding)setPart('foundation');
    box(x,.35,z,w+.65,.7,d+.65,palette.stone,angle,cat);
    if(activeBuilding)setPart('walls');
    box(x,h/2+.6,z,w,h,d,color,angle,cat);
    if(activeBuilding)setPart('details');
    box(x,h+.65,z,w+.65,.32,d+.65,palette.ivory,angle,cat);
    if(floors>1)box(x,4.15,z,w+.16,.18,d+.16,palette.ivory,angle,cat);
    const rh=d*.27;hippedRoof(x,z,w+1.3,d+1.3,h+.84,rh,roof,angle,cat);
    const nc=Math.max(3,Math.round(w/4.2));
    for(let side of [-1,1])for(let f=0;f<floors;f++)for(let i=0;i<nc;i++){
      const lx=(i-(nc-1)/2)*(w-3.6)/nc, lz=side*(d/2+.05);
      const a=angle+(side===-1?Math.PI:0);
      windowAt(x,z,a,lx,d/2+.05,.95+f*(h/floors),1.10,floors>1?2.05:1.65,cat,ornate);
    }
    // Side façades receive windows too, so street-level walking works from every angle.
    for(let side of [-1,1])for(let f=0;f<floors;f++)for(let i=0;i<2;i++)windowAt(x,z,angle+side*Math.PI/2,(i-.5)*d*.43,w/2+.03,1+f*(h/floors),1.05,1.85,cat,false);
    lbox(x,z,angle,0,1.5,d/2+.10,1.5,2.4,.24,palette.door,cat);
    lbox(x,z,angle,0,.28,d/2+.75,2.3,.5,1.5,palette.stone,cat);
    if(attic){
      lbox(x,z,angle,0,h+2,d*.15,w*.32,3.1,d*.56,color,cat);
      const p=local(x,z,angle,0,d*.15);gableRoof(p[0],p[1],w*.35,d*.6,h+3.55,1.1,roof,angle,cat);
      windowAt(x,z,angle,-1,d*.44,h+.8,.95,1.7,cat);windowAt(x,z,angle,1,d*.44,h+.8,.95,1.7,cat);
    }
    for(let i=0;i<(w>25?2:1);i++){const p=local(x,z,angle,(i?-.25:.25)*w,-d*.12);box(p[0],h+rh+.8,p[1],.75,2.7,.9,palette.brick,angle,cat);box(p[0],h+rh+2.2,p[1],1.05,.25,1.2,palette.chalk,angle,cat);}
    if(ornate)for(let side of [-1,1])lbox(x,z,angle,side*(w/2-.5),h/2,d/2+.14,.65,h,.28,palette.ivory,cat);
    if(sign)signboard(x,z,angle,sign,Math.min(w-2,14),3.65,d/2+.3,cat);
    const radius=Math.sqrt(w*w+d*d)/2;solids.push({x,z,w:w+1,d:d+1,angle,radius,category:cat});
    return {x,z,w,d,h,angle};
  }
  function signboard(x,z,a,text,w,y,lz,cat='known'){
    const c=document.createElement('canvas');c.width=1024;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#3d453e';ctx.fillRect(0,0,1024,128);ctx.strokeStyle='#bfa879';ctx.lineWidth=4;ctx.strokeRect(7,7,1010,114);ctx.fillStyle='#f2e7c8';ctx.font='54px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,512,67,980);
    const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;const material=new THREE.MeshBasicMaterial({map:t});const p=local(x,z,a,0,lz);const m=new THREE.Mesh(new THREE.PlaneGeometry(w,w/8),material);m.position.set(p[0],y,p[1]);m.rotation.y=a;(cat==='ordinary'?background:established).add(m);
  }
  function clip(a,b,boxBound){
    let lo=0,hi=1;const dx=b[0]-a[0],dy=b[1]-a[1];const pp=[-dx,dx,-dy,dy],qq=[a[0]-boxBound[0],boxBound[1]-a[0],a[1]-boxBound[2],boxBound[3]-a[1]];
    for(let i=0;i<4;i++){if(Math.abs(pp[i])<1e-10){if(qq[i]<0)return null;}else{const t=qq[i]/pp[i];if(pp[i]<0)lo=Math.max(lo,t);else hi=Math.min(hi,t);}}if(lo>hi)return null;return [[a[0]+lo*dx,a[1]+lo*dy],[a[0]+hi*dx,a[1]+hi*dy]];
  }
  const bounds=GEOGRAPHY.bounds;
  for(let index=0;index<GEOGRAPHY.roads.length;index++){
    const r=GEOGRAPHY.roads[index];
    for(let i=1;i<r.points.length;i++){
      const cl=clip(r.points[i-1],r.points[i],bounds);if(!cl)continue;
      roadSegments.push({a:cl[0],b:cl[1],width:r.width,name:r.name,modern:r.modern,main:index===0});
    }
  }
  buildSurfaces(push,{cobble,track,shoulder:palette.soil,paths:track,water:waterMat,bank:palette.soil});
  const distSegment=(x,z,a,b)=>{const dx=b[0]-a[0],dz=b[1]-a[1],l=dx*dx+dz*dz;const t=l?THREE.MathUtils.clamp(((x-a[0])*dx+(z-a[1])*dz)/l,0,1):0;return Math.hypot(x-a[0]-t*dx,z-a[1]-t*dz);};
  const nearRoad=(x,z,margin=0)=>roadSegments.some(r=>distSegment(x,z,r.a,r.b)<r.width/2+margin);
  function fence(x1,z1,x2,z2,h=1.4,cat='ordinary',iron=false,baseY=0){
    cat='fences';
    const dx=x2-x1,dz=z2-z1,len=Math.hypot(dx,dz),a=Math.atan2(-dz,dx),m=iron?palette.iron:palette.weathered;
    fenceSegments.push({a:[x1,z1],b:[x2,z2],minX:Math.min(x1,x2),maxX:Math.max(x1,x2),minZ:Math.min(z1,z2),maxZ:Math.max(z1,z2)});
    box((x1+x2)/2,baseY+h*.38,(z1+z2)/2,len,.09,.1,m,a,cat);box((x1+x2)/2,baseY+h*.83,(z1+z2)/2,len,.09,.1,m,a,cat);
    const num=Math.ceil(len/(iron?1.0:2.4));for(let i=0;i<=num;i++){const t=i/num;box(x1+dx*t,baseY+h/2,z1+dz*t,iron?.06:.12,h,iron?.06:.13,m,0,cat);}
  }
  function tree(x,z,size=1,cat='landscape',pine=false){
    cat='vegetation';
    const h=between(4.8,8.4)*size;cylinder(x,h*.36,z,.19*size,h*.72,palette.wood,cat);
    if(pine){const cone=new THREE.ConeGeometry(1,1,7);for(let i=0;i<3;i++)push(cone,palette.leaf3,x,h*.54+i*size*1.3,z,size*(2.4-i*.5),size*3.8,size*(2.4-i*.5),rnd()*3,cat);cone.dispose();}
    else for(let i=0;i<3;i++)push(unitSphere,[palette.leaf,palette.leaf2,palette.leaf3][Math.floor(rnd()*3)],x+between(-1,1)*size,h*.64+i*.7*size,z+between(-1,1)*size,between(1.5,2.6)*size,between(2,3.1)*size,between(1.5,2.6)*size,rnd()*6,cat);
  }
  function churchEnclosure(id){
    const {corners,gateEnds,segments,angle}=enclosureLayout(id);
    const baseY=-.25;
    for(const [a,b] of segments)fence(...a,...b,1.8,'fences',true,baseY);
    // Identical plinths and piers keep the whole perimeter on one level.
    for(const [x,z] of [...corners,...gateEnds]){
      box(x,baseY+1.2,z,.7,2.4,.7,palette.ivory,angle,'fences');
      box(x,baseY+2.48,z,.84,.16,.84,palette.stone,angle,'fences');
      solids.push({x,z,w:.84,d:.84,angle,radius:.6,category:'fences'});
    }
  }
  function churchWindow(x,z,a,lx,lz,y,w=1.6,h=3.5){
    const p=local(x,z,a,lx,lz);arch(p[0],y,p[1],w+.48,h+.25,.20,palette.ivory,a);const p2=local(x,z,a,lx,lz+.21);arch(p2[0],y+.12,p2[1],w,h-.05,.04,palette.glass,a);
    lbox(x,z,a,lx,y+h*.43,lz+.3,.10,h*.86,.08,palette.chalk);
  }
  function belfry(x,z,bottom,width,height){
    box(x,bottom+height/2,z,width,height,width,palette.ivory);
    for(let side=0;side<4;side++){
      const a=side*Math.PI/2,p=local(x,z,a,0,width/2+.03);
      arch(p[0],bottom+height*.18,p[1],width*.45,height*.72,.05,palette.door,a);
      for(const j of [-1,1])lbox(x,z,a,j*width*.37,bottom+height/2,width/2+.12,.42,height-.5,.32,palette.chalk);
    }
    box(x,bottom+height+.18,z,width+.8,.36,width+.8,palette.chalk);
  }
  buildPokrov({box,cylinder,hippedRoof,lathe,onion,arch,churchWindow,palette,solids,landmarkBounds,setBuilding,setPart,push});
  // The church lane and yards are artistic infill on the real street layout.
  churchEnclosure('pokrov');
  for(const [xx,zz] of [[333,-10],[339,27],[372,-13],[376,22]])tree(xx,zz,.72);
  for(const [x,z] of [[335,-10],[335,24]]){
    box(x,.55,z,2.2,.16,.56,palette.weathered);
    for(const dx of [-.82,.82])box(x+dx,.3,z,.12,.6,.46,palette.wood);
  }
  for(const [x,z] of [[333,23]]){
    cylinder(x,.6,z,.48,1.2,palette.darkwood);
    for(const y of [.18,.98])cylinder(x,y,z,.5,.06,palette.iron);
  }
  // Trinity cathedral: late classicism, five domes, porticoes, restored west tower.
  {
    setBuilding('trinity');setPart('walls');
    const [cx,z]=GEOGRAPHY.landmarks.trinity.point;const x=cx+4;
    setPart('foundation');box(x,.5,z,24,1,25,palette.stone);setPart('walls');box(x,7,z,23,13,23,palette.ivory);setPart('details');box(x,13.7,z,24.4,.75,24.4,palette.chalk);hippedRoof(x,z,25,25,14.1,3.8,palette.dome);
    for(const side of [-1,1]){
      const a=side===1?0:Math.PI;
      for(const xx of [-7.5,-3,3,7.5])churchWindow(x,z,a,xx,11.65,6.2,1.7,4.7);
      lbox(x,z,a,0,1.0,15,15,1.2,6,palette.stone);
      for(let j=0;j<4;j++){const p=local(x,z,a,(j-1.5)*3.2,16);cylinder(p[0],5.7,p[1],.49,9.2,palette.chalk);cylinder(p[0],1.2,p[1],.75,.4,palette.ivory);cylinder(p[0],10.4,p[1],.78,.5,palette.ivory);}
      lbox(x,z,a,0,11.1,15,15.3,.8,4.5,palette.chalk);
      const p=local(x,z,a,0,12.65);const pediment=new THREE.Shape();pediment.moveTo(-7.8,0);pediment.lineTo(7.8,0);pediment.lineTo(0,3.2);pediment.closePath();const pedimentGeo=new THREE.ExtrudeGeometry(pediment,{depth:4.7,bevelEnabled:false});push(pedimentGeo,palette.ivory,p[0],11.5,p[1],1,1,1,a);pedimentGeo.dispose();
    }
    cylinder(x,18.8,z,5.1,7.0,palette.ivory);cylinder(x,22.4,z,5.4,.5,palette.chalk);
    for(let i=0;i<8;i++)churchWindow(x,z,i*Math.PI/4,0,5.13,16.8,1.4,3.9);
    lathe(x,22.65,z,[[5.6,0],[5.4,1.1],[4.4,2.5],[2.1,3.5],[1.2,3.8]],palette.dome);cylinder(x,27.1,z,1.25,1.9,palette.chalk);onion(x,28,z,2.4,4.5);
    for(const dx of [-7.8,7.8])for(const dz of [-7.8,7.8]){cylinder(x+dx,18.5,z+dz,1.8,4.1,palette.ivory);onion(x+dx,20.6,z+dz,2.05,3.5);}
    const bx=cx-22;box(cx-13,5,z,13,10,13,palette.ivory);hippedRoof(cx-13,z,14,14,10,2.5,palette.roof);
    box(bx,5.6,z,9,11.2,10,palette.ivory);belfry(bx,z,11.2,8.1,8.6);belfry(bx,z,20.3,6.9,7.5);
    lathe(bx,28.2,z,[[4.2,0],[3.8,1.4],[2.7,2.9],[1.3,4.0]],palette.dome);cylinder(bx,32.9,z,1.15,1.7,palette.chalk);onion(bx,33.7,z,1.9,3.8);
    setBuilding(null);churchEnclosure('trinity');
    for(const dz of [-23,23])for(const dx of [-26,-10,24]){const p=local(-15.5,-70.35,.165,dx,dz);tree(p[0],p[1],.7,'known');}
    solids.push({x,z,w:26,d:27,angle:0,radius:20,category:'known'},{x:bx,z,w:14,d:14,angle:0,radius:10,category:'known'});
    landmarkBounds.trinity=new THREE.Box3(new THREE.Vector3(cx-30,0,z-19),new THREE.Vector3(cx+18,40,z+19));
  }
  const kornilova=buildKornilova({setBuilding,setPart,push,box,lbox,local,palette,surfaceMaterials,solids,fenceSegments,landmarkBounds});
  {
    setBuilding('police');const [x,z]=GEOGRAPHY.landmarks.police.point;
    building({x,z,w:33.0,d:13.4,h:8,angle:.172+Math.PI,color:palette.blue,cat:'known',ornate:true,roof:palette.roof2});
    setBuilding(null);
  }
  const heritageReservations=buildHeritage({setBuilding,setPart,push,box,lbox,local,hippedRoof,windowAt,arch,palette,surfaceMaterials,solids,landmarkBounds});
  // Reserved church precincts and named buildings; ordinary plots never displace them.
  const reservations=[{x:GEOGRAPHY.landmarks.pokrov.point[0],z:GEOGRAPHY.landmarks.pokrov.point[1],w:82,d:64},
    {x:GEOGRAPHY.landmarks.trinity.point[0]-3,z:GEOGRAPHY.landmarks.trinity.point[1],w:88,d:77},
    {x:GEOGRAPHY.landmarks.inn.point[0],z:GEOGRAPHY.landmarks.inn.point[1],w:58,d:43},
    {x:GEOGRAPHY.landmarks.police.point[0],z:GEOGRAPHY.landmarks.police.point[1],w:52,d:39},...heritageReservations];
  const inReserve=(x,z,extra=0)=>reservations.some(r=>Math.abs(x-r.x)<r.w/2+extra&&Math.abs(z-r.z)<r.d/2+extra);
  const ordinary=[];
  const houseColors=[palette.plaster,palette.ochre,palette.brick2,palette.weathered,palette.timber,palette.chalk,palette.blue];
  const candidateRoads=[...roadSegments].sort((a,b)=>Number(b.main)-Number(a.main));
  for(const road of candidateRoads){
    const dx=road.b[0]-road.a[0],dz=road.b[1]-road.a[1],len=Math.hypot(dx,dz);if(len<12)continue;const nx=-dz/len,nz=dx/len,a=Math.atan2(-dz,dx);
    for(let t=12+between(0,8);t<len;t+=between(25,37))for(const side of [-1,1]){
      const w=between(13,22),d=between(9,14),offset=road.width/2+d/2+between(3,7),x=road.a[0]+dx*t/len+nx*offset*side,z=road.a[1]+dz*t/len+nz*offset*side;
      if(x<-640||x>510||z<-300||z>216||inReserve(x,z,14)||nearRoad(x,z,Math.max(w,d)*.45))continue;
      if(ordinary.some(p=>Math.hypot(p.x-x,p.z-z)<(w+p.w)*.56))continue;
      // Sparse settlement east of the historic city edge and in outer gardens.
      if(x>425&&rnd()<.75)continue;
      const floors=road.main?(rnd()<.85?2:1):(rnd()<.24?2:1),h=floors===2?between(6.9,8.4):between(3.9,4.8),angle=a+(side>0?Math.PI:0);
      building({x,z,w,d,h,angle,color:houseColors[Math.floor(rnd()*houseColors.length)],roof:[palette.roof,palette.roof2,palette.roof3][Math.floor(rnd()*3)],floors,attic:road.main&&floors===2&&rnd()<.6,cat:'ordinary',ornate:road.main&&rnd()<.35});
      ordinary.push({x,z,w,d});
      const rear=local(x,z,angle,0,-d/2-12);
      if(!nearRoad(rear[0],rear[1],10)&&!inReserve(rear[0],rear[1],9)){
        box(rear[0],-.035,rear[1],w,0.035,18,palette.soil,angle,'ordinary');
        for(let i=0;i<4;i++)lbox(rear[0],rear[1],angle,(i-1.5)*3.3,.006,0,1.8,.025,12,palette.garden,'ordinary');
        const p1=local(x,z,angle,-w/2-1,-d/2-23),p2=local(x,z,angle,w/2+1,-d/2-23);fence(...p1,...p2,1.35,'ordinary');
        if(rnd()<.8)tree(rear[0]+between(-w/2,w/2),rear[1]+between(-6,6),.67,'ordinary');
        if(rnd()<.35){const s=local(x,z,angle,w*.35,-d/2-19);building({x:s[0],z:s[1],w:7,d:5,h:2.4,floors:1,angle,color:palette.wood,roof:palette.roof3,cat:'ordinary'});}
      }
    }
  }
  // Trees follow gardens and the river valley; exact planting is interpretative.
  let placedTrees=0;
  for(let i=0;i<650;i++){
    const x=between(-1050,1150),z=between(-740,680);
    if(nearRoad(x,z,7)||inReserve(x,z,8)||ordinary.some(p=>Math.hypot(p.x-x,p.z-z)<Math.max(p.w,p.d)*.75))continue;
    if(x>-680&&x<500&&z>-310&&z<220&&rnd()<.87)continue;
    if(GEOGRAPHY.water.some(r=>r.some(p=>Math.hypot(x-p[0],z-p[1])<8)))continue;
    tree(x,z,between(.75,1.7),'landscape',rnd()<.32);placedTrees++;
  }
  // A timber crossing follows the main road over the Shitka.
  const bridgeX=(39.18637-GEOGRAPHY.origin[1])*111320*Math.cos(GEOGRAPHY.origin[0]*Math.PI/180),bridgeZ=-(55.918865-GEOGRAPHY.origin[0])*111320;
  box(bridgeX,.17,bridgeZ,20,.30,24,palette.weathered,.15);
  for(let i=0;i<12;i++){const p=local(bridgeX,bridgeZ,.15,-9+i*1.65,0);box(p[0],.35,p[1],.13,.05,24,palette.wood,.15);}
  for(const s of [-1,1]){const a=local(bridgeX,bridgeZ,.15,-10,s*12),b=local(bridgeX,bridgeZ,.15,10,s*12);fence(...a,...b,1.35,'known');}
  const streetLighting=buildStreetLighting({scene,roads:roadSegments,box,cylinder,hippedRoof,palette,collide,nearRoad,solids,exclusions:['pokrov','trinity'].flatMap(id=>enclosureLayout(id).gateEnds),landmarkPoints:Object.values(GEOGRAPHY.landmarks).filter(p=>p.coordinates).map(p=>p.point)});
  // Dynamic street life: small figures and horse-drawn carts move along the road.
  const actorMats=['#675242','#8c7861','#b0bdb8','#a78066'].map(color=>mat(color));
  const actorDark=mat('#554a3d'),skin=mat('#b89a78'),horse=mat('#675242');
  function actorBox(parent,w,h,d,x,y,z,m){const mesh=new THREE.Mesh(unitBox,m);mesh.scale.set(w,h,d);mesh.position.set(x,y,z);mesh.castShadow=true;parent.add(mesh);return mesh;}
  function person(scaleVal=1){
    const p=new THREE.Group(),coat=actorMats[Math.floor(rnd()*actorMats.length)];actorBox(p,.43,.74,.24,0,1.04,0,coat);const head=new THREE.Mesh(new THREE.SphereGeometry(.145,8,6),skin);head.position.y=1.59;p.add(head);actorBox(p,.37,.12,.32,0,1.76,0,actorDark);
    const legs=[],arms=[];for(const s of [-1,1]){const pivot=new THREE.Group();pivot.position.set(s*.12,.76,0);p.add(pivot);actorBox(pivot,.14,.63,.16,0,-.3,0,actorDark);legs.push(pivot);arms.push(actorBox(p,.12,.64,.16,s*.29,1.03,0,coat));}p.scale.setScalar(scaleVal);p.userData.legs=legs;p.userData.arms=arms;return p;
  }
  function cart(){
    const p=new THREE.Group();actorBox(p,1.5,.65,2.0,0,1.1,0,palette.wood);actorBox(p,1.35,.17,1.7,0,1.45,0,palette.soil);
    const wheels=[];for(const x of [-.86,.86])for(const z of [-.65,.65]){const g=new THREE.Group();g.position.set(x,.62,z);g.rotation.z=Math.PI/2;const wheel=new THREE.Mesh(new THREE.TorusGeometry(.49,.07,5,12),palette.darkwood);wheel.rotation.x=Math.PI/2;g.add(wheel);for(let k=0;k<4;k++){const spoke=new THREE.Mesh(new THREE.BoxGeometry(.055,.09,.94),palette.wood);spoke.rotation.y=k*Math.PI/4;g.add(spoke);}p.add(g);wheels.push(g);}
    actorBox(p,.62,.74,1.48,0,1.2,-2.45,horse);const neck=actorBox(p,.4,.75,.42,0,1.67,-3.0,horse);neck.rotation.x=-.4;actorBox(p,.36,.36,.70,0,1.9,-3.3,horse);
    const legs=[];for(const x of [-.22,.22])for(const z of [-2.9,-2]){const g=new THREE.Group();g.position.set(x,1.0,z);p.add(g);actorBox(g,.12,.9,.13,0,-.45,0,horse);legs.push(g);}
    for(const s of [-1,1]){actorBox(p,.075,.075,2,s*.55,1,-1.65,palette.wood);actorBox(p,.09,.24,.12,s*.14,2.2,-3.24,horse);}
    const driver=person(.84);driver.position.set(0,.85,-.35);p.add(driver);p.userData={legs,wheels};return p;
  }
  const streetLife=buildStreetLife({parent:layers.residents,person,cart,roads:roadSegments,collide,rnd});
  for(const batch of batches.values()){
    if(!batch.geometries.length)continue;
    const merged=mergeGeometries(batch.geometries,false);
    if(!merged)throw new Error('Не удалось собрать геометрию города');
    merged.computeBoundingSphere();const m=new THREE.Mesh(merged,batch.material);m.castShadow=batch.category!=='surfaces'&&!batch.material.transparent;m.receiveShadow=true;
    const parent=batch.building?historicModels[batch.building][batch.part]:(layers[batch.category]||(batch.category==='ordinary'?background:established));
    m.name=batch.building?batch.building+'/'+batch.part:batch.category+'/chunk';parent.add(m);
    if(batch.detail)detailMeshes.push(m);
    for(const g of batch.geometries)g.dispose();
  }
  landmarkBounds.police=new THREE.Box3().setFromObject(historicModels.police.group);
  streetLighting.bindMaterials(scene);
  unitCylinder.dispose();unitSphere.dispose();
  function update(dt,time,active){streetLife.update(dt,time,active);}
  function setQuality(value,anisotropy){quality=value;surfaceMaterials.setQuality(value,anisotropy);pavingMaterials.setQuality(value,anisotropy);streetLighting.setQuality(value);}
  function updateVisibility(camera){
    let changed=false;const show=(mesh,visible)=>{if(mesh.visible!==visible){mesh.visible=visible;changed=true;}};
    const distance=quality==='low'?220:quality==='high'?620:380;
    const span=camera.isOrthographicCamera?(camera.top-camera.bottom)/camera.zoom:null;
    for(const m of detailMeshes)show(m,span!==null?span<distance*1.5:camera.position.distanceTo(m.geometry.boundingSphere.center)-m.geometry.boundingSphere.radius<distance);
    for(const [id,model] of Object.entries(historicModels)){
      const [x,z]=GEOGRAPHY.landmarks[id].point;
      show(model.details,span!==null?span<distance*2.3:Math.hypot(camera.position.x-x,camera.position.y,camera.position.z-z)<distance*1.8);
    }
    const far=quality==='low'?750:1400;
    for(const m of layers.vegetation.children)show(m,camera.position.distanceTo(m.geometry.boundingSphere.center)-m.geometry.boundingSphere.radius<far);
    return changed;
  }
  function collide(x,z,clearance=.65){
    if(x<bounds[0]||x>bounds[1]||z<bounds[2]||z>bounds[3])return true;
    const edge=clearance+.08;
    if(layers.fences.visible&&fenceSegments.some(f=>x>=f.minX-edge&&x<=f.maxX+edge&&z>=f.minZ-edge&&z<=f.maxZ+edge&&distSegment(x,z,f.a,f.b)<edge))return true;
    return solids.some(b=>{
      if(!background.visible&&b.category==='ordinary'||!layers.fences.visible&&b.category==='fences')return false;
      if(Math.hypot(x-b.x,z-b.z)>b.radius+clearance)return false;
      if(b.polygon){let inside=false;for(let i=0,j=b.polygon.length-1;i<b.polygon.length;j=i++){const a=b.polygon[i],p=b.polygon[j];if(distSegment(x,z,a,p)<clearance)return true;if((a[1]>z)!==(p[1]>z)&&x<(p[0]-a[0])*(z-a[1])/(p[1]-a[1])+a[0])inside=!inside;}return inside;}
      const dx=x-b.x,dz=z-b.z,c=Math.cos(b.angle),s=Math.sin(b.angle);return Math.abs(c*dx-s*dz)<b.w/2+clearance&&Math.abs(s*dx+c*dz)<b.d/2+clearance;
    });
  }
  const setTime=hour=>{streetLighting.setTime(hour);kornilova.setTime(hour);};
  return {background,established,layers,historicModels,landmarkBounds,roadSegments,solids,fenceSegments,update,collide,setQuality,updateVisibility,streetLife,streetLighting,setTime,loadMaterials:surfaceMaterials.load,ordinaryCount:ordinary.length,treeCount:placedTrees,actorCount:streetLife.actors.length,palette};
}
