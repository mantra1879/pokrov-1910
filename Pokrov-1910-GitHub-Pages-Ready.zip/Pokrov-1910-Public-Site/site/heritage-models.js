import * as THREE from './assets/three.module.js';
import { GEOGRAPHY } from './geography.js';
import { FEMALE_ROOF } from './female-roof-data.js';
import { CIVIC_ROOF } from './civic-roof-data.js';

// Individually modelled landmarks. Outlines are surviving OSM footprints;
// heights, roof pitches and simplified ornaments are photographic estimates.
export function buildHeritage({setBuilding,setPart,push,box,lbox,local,hippedRoof,windowAt,arch,palette,surfaceMaterials,solids,landmarkBounds}) {
  const paint=(color,kind='plaster')=>surfaceMaterials.finish(new THREE.MeshStandardMaterial({color,roughness:.9}),kind);
  const red=paint('#aa503b','brick'),pink=paint('#bb6758'),cream=paint('#dcc996');
  const grey=paint('#a5afa2'),white=palette.ivory,roof=palette.roof;
  const specs={
    male:{h:10.6,color:cream,trim:white,first:2.7,second:3.15},
    female:{h:9.6,color:red,trim:palette.brick2,first:2.25,second:2.65},
    civic:{h:10.7,color:pink,trim:white,first:1.85,second:4.5,upper:4.15},
    hospital:{h:9.5,color:cream,trim:palette.ochre,first:2.1,second:2.75},
    administrative:{h:8.7,color:red,trim:palette.brick2,first:2.05,second:2.6},
    treasury:{h:4.8,color:white,trim:white,first:2.6,floors:1},
    annex:{h:4.3,color:paint('#416955'),trim:white,first:2.05,floors:1},
    cheburov:{h:3.8,color:palette.darkwood,trim:white,first:1.6,floors:1},
    lenina47:{h:7.2,color:paint('#b26c52','brick'),trim:palette.ochre,first:2.1,second:2.35},
    lenina80:{h:7.7,color:red,trim:cream,first:2.0,second:2.45},
    lenina86:{h:4.4,color:paint('#a99b7e'),trim:paint('#d6c8a9'),first:1.7,floors:1},
    lenina106:{h:5.4,color:paint('#c8b791'),trim:white,first:1.75,floors:1}
  };
  const positions={};
  const recessedWindows=[];
  function openingsFor(id,sp,len){
    const openings=[];if(len<4)return openings;
    const n=Math.max(1,Math.round(len/(id==='male'?4.4:3.6))),spacing=(len-1.5)/n;
    for(let j=0;j<n;j++)for(let f=0;f<(sp.floors||2);f++)openings.push({x:(j-(n-1)/2)*spacing,y:f?(sp.upper||5.25):1.1,w:Math.min(1.45,spacing*.5),h:f?sp.second:sp.first});
    return openings;
  }
  function wallWithOpenings(cx,cz,fa,len,sp,openings){
    const wall=new THREE.Shape();wall.moveTo(-len/2,0);wall.lineTo(len/2,0);wall.lineTo(len/2,sp.h);wall.lineTo(-len/2,sp.h);wall.closePath();
    for(const o of openings){const hole=new THREE.Path();hole.moveTo(o.x-o.w/2,o.y-.5);hole.lineTo(o.x-o.w/2,o.y+o.h-.5);hole.lineTo(o.x+o.w/2,o.y+o.h-.5);hole.lineTo(o.x+o.w/2,o.y-.5);hole.closePath();wall.holes.push(hole);}
    const geo=new THREE.ExtrudeGeometry(wall,{depth:.42,bevelEnabled:false}),p=local(cx,cz,fa,0,-.42);
    setPart('walls');push(geo,sp.color,p[0],.5,p[1],1,1,1,fa);geo.dispose();setPart('details');
  }
  function gable(x,z,a,width,y,height,material,shape='point') {
    const s=new THREE.Shape();s.moveTo(-width/2,0);
    if(shape==='curve') {s.lineTo(-width/2,height*.22);s.bezierCurveTo(-width*.32,height*.28,-width*.2,height*.8,0,height);s.bezierCurveTo(width*.2,height*.8,width*.32,height*.28,width/2,height*.22);}
    else if(shape==='steps') {s.lineTo(-width/2,height*.3);s.lineTo(-width*.3,height*.3);s.lineTo(-width*.3,height*.6);s.lineTo(-width*.12,height*.6);s.lineTo(-width*.12,height);s.lineTo(width*.12,height);s.lineTo(width*.12,height*.6);s.lineTo(width*.3,height*.6);s.lineTo(width*.3,height*.3);s.lineTo(width/2,height*.3);}
    else s.lineTo(0,height);
    s.lineTo(width/2,0);s.closePath();
    const geo=new THREE.ExtrudeGeometry(s,{depth:.45,bevelEnabled:false,curveSegments:12});push(geo,material,x,y,z,1,1,1,a);geo.dispose();
  }
  function ornament(x,z,a,w,y,h,color,style='point') {
    gable(x,z,a,w,y,h,color,style);
    const p=local(x,z,a,0,.47);
    if(h>2)arch(p[0],y+.35,p[1],.85,1.3,.08,palette.glass,a);
  }
  for(const [id,sp] of Object.entries(specs)) {
    setBuilding(id);setPart('walls');
    const g=GEOGRAPHY.landmarks[id], [x,z]=g.point, a=g.angle;
    const outline=g.outline.slice(0,-1),s=new THREE.Shape();
    outline.forEach((p,i)=>i?s.lineTo(p[0],-p[1]):s.moveTo(p[0],-p[1]));s.closePath();
    const recessed=id==='female'||id==='cheburov';
    if(recessed){
      const floor=new THREE.ShapeGeometry(s);floor.rotateX(-Math.PI/2);push(floor,sp.color,0,.52,0);push(floor,sp.color,0,sp.h+.5,0);floor.dispose();
    }else {const geo=new THREE.ExtrudeGeometry(s,{depth:sp.h,bevelEnabled:false});geo.rotateX(-Math.PI/2);push(geo,sp.color,0,.5,0);geo.dispose();}
    setPart('details');
    const area=outline.reduce((v,p,i)=>{const q=outline[(i+1)%outline.length];return v+p[0]*q[1]-q[0]*p[1];},0);
    for(let i=0;i<outline.length;i++) {
      const p=outline[i],q=outline[(i+1)%outline.length],dx=q[0]-p[0],dz=q[1]-p[1],len=Math.hypot(dx,dz);
      if(len<.4)continue;
      const nx=(area>0?1:-1)*dz/len,nz=(area>0?-1:1)*dx/len,fa=Math.atan2(nx,nz),cx=(p[0]+q[0])/2,cz=(p[1]+q[1])/2;
      const openings=openingsFor(id,sp,len);
      if(recessed)wallWithOpenings(cx,cz,fa,len,sp,openings);
      setPart('foundation');lbox(cx,cz,fa,0,.4,.04,len,.65,.35,palette.stone);setPart('details');
      lbox(cx,cz,fa,0,sp.h+.5,.10,len+.25,.35,.5,sp.trim);
      lbox(cx,cz,fa,0,sp.h+.8,.10,len+.50,.20,.70,sp.trim);
      if(sp.floors!==1)lbox(cx,cz,fa,0,id==='civic'?3.55:4.75,.07,len,.25,.3,sp.trim);
      if(len<4)continue;
      for(const o of openings){
        windowAt(cx,cz,fa,o.x,id==='cheburov'?.18:.04,o.y,o.w,o.h,'known',false,sp.trim,recessed);
        if(recessed){const p=local(cx,cz,fa,o.x,0);recessedWindows.push({id,centre:[p[0],o.y+o.h*.28,p[1]],normal:[nx,0,nz],width:o.w,height:o.h});}
      }
      // Lightly incised courses and quoins convey the photographed masonry.
      if(id==='cheburov'){
        // Rounded horizontal logs with projecting corner joints.
        for(let yy=.68;yy<sp.h+.4;yy+=.27){
          let spans=[[-len/2-.15,len/2+.15]];
          for(const o of openings)if(yy+.13>o.y&&yy-.13<o.y+o.h){const left=o.x-o.w/2-.06,right=o.x+o.w/2+.06;spans=spans.flatMap(([a,b])=>b<=left||a>=right?[[a,b]]:[[a,Math.min(b,left)],[Math.max(a,right),b]].filter(([a,b])=>b-a>.03));}
          for(const [left,right] of spans){const length=right-left,log=new THREE.CylinderGeometry(.13,.13,length,8);log.rotateZ(Math.PI/2);log.userData.logLength=length;log.userData.logRadius=.13;log.userData.logUVOffset=[-right/2.4+yy*.19,yy*.93];const lp=local(cx,cz,fa,(left+right)/2,.035);push(log,palette.darkwood,lp[0],yy,lp[1],1,1,1,fa);log.dispose();}
        }
      }
      else for(const xx of [-len/2+.4,len/2-.4]) {
        lbox(cx,cz,fa,xx,sp.h/2+.5,.11,.60,sp.h,.3,sp.trim);
        if(id==='civic'||id==='male'||id==='hospital')for(let yy=1;yy<4;yy+=.55)lbox(cx,cz,fa,xx,yy,.3,.78,.35,.2,sp.trim);
      }
    }
    const maxx=Math.max(...outline.map(p=>p[0])),minx=Math.min(...outline.map(p=>p[0])),maxz=Math.max(...outline.map(p=>p[1])),minz=Math.min(...outline.map(p=>p[1]));
    solids.push({x,z,w:g.w,d:g.d,angle:a,radius:Math.hypot(g.w,g.d)/2,polygon:outline,category:'known'});
    landmarkBounds[id]=new THREE.Box3(new THREE.Vector3(minx-.5,0,minz-.5),new THREE.Vector3(maxx+.5,sp.h+7,maxz+.5));
    positions[id]={x,z,a,w:g.w,d:g.d,sp};
  }
  function roofPart(id,lx,lz,w,d,rise=2.7){setBuilding(id);setPart('roof');const p=positions[id],q=local(p.x,p.z,p.a,lx,lz);hippedRoof(q[0],q[1],w+.8,d+.8,p.sp.h+.95,rise,id==='cheburov'?palette.roof3:roof,p.a);setPart('details');}
  function fittedRoof(id,data){
    const p=positions[id];setBuilding(id);setPart('roof');
    const indexed=new THREE.BufferGeometry();indexed.setAttribute('position',new THREE.Float32BufferAttribute(data.vertices,3));indexed.setIndex(data.indices);
    const geometry=indexed.toNonIndexed();geometry.computeVertexNormals();
    push(geometry,roof,p.x,0,p.z,1,1,1,p.a);geometry.dispose();indexed.dispose();setPart('details');
  }
  function front(id,angle,lx,lz,width,height=1.9,style='point'){
    setBuilding(id);
    const p=positions[id],q=local(p.x,p.z,angle,lx,lz);ornament(q[0],q[1],angle,width,p.sp.h+.8,height,p.sp.trim,style);
  }
  function entrance(id,angle,lx,lz,tall=false) {
    setBuilding(id);
    const p=positions[id],q=local(p.x,p.z,angle,lx,lz);
    lbox(q[0],q[1],angle,0,1.75,0,1.65,2.9,.28,palette.door);
    for(let j=0;j<3;j++)lbox(q[0],q[1],angle,0,.12+j*.18,1.1-j*.25,2.7-j*.2,.25,2.1-j*.3,palette.stone);
    lbox(q[0],q[1],angle,0,tall?4.0:3.35,1.1,3.5,.20,2.5,palette.metal);
    for(const k of [-1,1])lbox(q[0],q[1],angle,k*1.45,tall?3:2.4,1.95,.075,1.65,.075,palette.iron);
  }
  // Male gymnasium: broad classroom wings, projecting centre and curved attic.
  {
    const p=positions.male;roofPart('male',0,3,48.3,22.4,3.2);roofPart('male',-3,-1.5,13.8,28.5,3.4);
    front('male',p.a,-3,p.d/2,13.8,3.9,'curve');
    const q=local(p.x,p.z,p.a,-3,p.d/2+.10);
    lbox(q[0],q[1],p.a,0,5.65,0,12.7,10.3,.45,p.sp.color);
    for(const dx of [-4,0,4]){windowAt(q[0],q[1],p.a,dx,.28,1.1,1.6,2.8,'known',false);windowAt(q[0],q[1],p.a,dx,.28,5.1,1.7,3.6,'known',false);}
    entrance('male',p.a,-3,p.d/2+.45);
  }
  // Female gymnasium: brick wings around the yard, entrance tower and tall end gables.
  {
    const p=positions.female;
    // A closed shell follows every rear return; it does not bridge the yard.
    fittedRoof('female',FEMALE_ROOF);
    // The long main facade faces east; the north end turns to Moskovskaya.
    const fa=p.a+Math.PI;
    for(const side of [-1,1])front('female',fa,side*14.3,p.d/2,11.5,5.1,'curve');
    front('female',fa,0,p.d/2+.30,5.4,4.2,'curve');
    const q=local(p.x,p.z,fa,0,p.d/2+.15);lbox(q[0],q[1],fa,0,5.1,0,4.5,9.2,.6,p.sp.color);
    const ar=local(q[0],q[1],fa,0,.35);arch(ar[0],5,ar[1],2.3,4.1,.15,white,fa);const ar2=local(q[0],q[1],fa,0,.52);arch(ar2[0],5.15,ar2[1],1.98,3.8,.1,palette.glass,fa);
    entrance('female',fa,0,p.d/2+.65);
  }
  // Civic offices: low ground storey, high ceremonial windows, white pilasters and parapets.
  {
    const p=positions.civic,fa=p.a+Math.PI;fittedRoof('civic',CIVIC_ROOF);
    for(const side of [-1,1]){
      const q=local(p.x,p.z,fa,side*14.0,12.3);
      lbox(q[0],q[1],fa,0,11.9,0,10.6,1.5,.6,p.sp.color);
      lbox(q[0],q[1],fa,0,12.72,0,11.2,.23,.82,white);
      for(let j=-2;j<=2;j++)lbox(q[0],q[1],fa,j*1.9,11.9,.36,.78,1.1,.16,white);
    }
    const q=local(p.x,p.z,fa,0,12.3);lbox(q[0],q[1],fa,0,5.8,0,9.4,10.3,.65,p.sp.color);
    for(const k of [-1,1]){lbox(q[0],q[1],fa,k*4.5,6.6,.5,.6,8.0,.4,white);windowAt(q[0],q[1],fa,k*2.5,.55,4.3,1.6,4.45,'known',false,white);}
    front('civic',fa,0,12.6,10.4,2.7,'steps');entrance('civic',fa,0,12.9,true);
  }
  // Hospital: a U-shaped court, battlemented entrance and stepped wing gables.
  {
    const p=positions.hospital;roofPart('hospital',0,-7.1,44.4,17.4,2.2);roofPart('hospital',-16.3,0,11.8,31.5,2.5);roofPart('hospital',16.1,0,12.2,31.5,2.5);
    for(const side of [-1,1])front('hospital',p.a,side*16.2,15.9,6.3,2.5,'steps');
    front('hospital',p.a,0,1.7,8.0,3.5,'steps');entrance('hospital',p.a,0,1.9);
    for(const k of [-1,1]){
      const q=local(p.x,p.z,p.a,k*4.2,1.9);box(q[0],6.1,q[1],.75,11.3,.8,p.sp.trim,p.a);
      for(let i=-1;i<=1;i++)lbox(q[0],q[1],p.a,i*.36,12.1,0,.25,.65,.8,p.sp.trim);
    }
  }
  // Lenina 81: street wing plus rear wings, brick attic over the north entrance.
  {
    const p=positions.administrative;roofPart('administrative',0,3.7,29.4,19.8,2.8);roofPart('administrative',-9,-10,11.4,7.3,2.5);roofPart('administrative',10.1,-9.0,9.1,5.6,2.5);
    const fa=.187+Math.PI;front('administrative',fa,-6.0,14.5,10,4.5,'curve');entrance('administrative',fa,-6.0,14.8);
  }
  for(const id of ['treasury','annex','cheburov']){const p=positions[id];roofPart(id,0,0,p.w,p.d,2.5);}
  {
    const p=positions.treasury,fa=.144;entrance('treasury',fa,0,p.w/2+.3);
  }
  {
    const p=positions.cheburov,fa=.158;entrance('cheburov',fa,0,p.w/2+.2);
  }
  // Individually selected addresses on former Moskovskaya Street. Their
  // mapped contemporary footprints are reliable; facade details remain
  // simplified interpretations of modern photographs and registry entries.
  {
    const p=positions.lenina47,fa=p.a+Math.PI;
    roofPart('lenina47',0,0,p.w,p.d,2.25);
    front('lenina47',fa,0,p.d/2,Math.min(12,p.w*.42),2.15,'steps');
    entrance('lenina47',fa,0,p.d/2+.2);
    const q=local(p.x,p.z,fa,0,p.d/2+.06);
    lbox(q[0],q[1],fa,0,1.45,.15,3.1,.32,.18,palette.ochre);
  }
  {
    const p=positions.lenina80,fa=p.a+Math.PI;
    roofPart('lenina80',0,0,p.w,p.d,3.0);
    front('lenina80',fa,0,p.d/2,Math.min(8.5,p.w*.8),2.6,'curve');
    for(const side of [-1,1])front('lenina80',fa,side*p.w*.28,p.d/2,Math.min(4.8,p.w*.42),1.55,'point');
    entrance('lenina80',fa,0,p.d/2+.2);
  }
  {
    const p=positions.lenina86,fa=p.a+Math.PI;
    roofPart('lenina86',0,0,p.w,p.d,2.15);
    front('lenina86',fa,0,p.d/2,Math.min(7.5,p.w*.76),1.65,'point');
    entrance('lenina86',fa,0,p.d/2+.18);
  }
  {
    const p=positions.lenina106,fa=p.a+Math.PI;
    roofPart('lenina106',0,0,p.w,p.d,2.35);
    front('lenina106',fa,0,p.d/2,Math.min(7.2,p.w*.8),1.75,'curve');
    entrance('lenina106',fa,0,p.d/2+.2);
    const q=local(p.x,p.z,fa,0,p.d/2+.06);
    lbox(q[0],q[1],fa,0,3.25,.08,p.w*.82,.20,.22,palette.ochre);
  }
  setBuilding(null);
  for(const id of ['female','cheburov']){
    // Diagnostic records describe only real openings in the rendered wall mesh.
    landmarkBounds[id].userData={recessedWindows:recessedWindows.filter(w=>w.id===id)};
  }
  return Object.keys(specs).map(id=>{const g=GEOGRAPHY.landmarks[id],xs=g.outline.map(p=>p[0]),zs=g.outline.map(p=>p[1]);return {x:(Math.max(...xs)+Math.min(...xs))/2,z:(Math.max(...zs)-Math.min(...zs))/2+Math.min(...zs),w:Math.max(...xs)-Math.min(...xs)+4,d:Math.max(...zs)-Math.min(...zs)+4};});
}
