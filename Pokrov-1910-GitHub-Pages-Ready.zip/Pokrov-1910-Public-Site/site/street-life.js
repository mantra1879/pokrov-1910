import * as THREE from './assets/three.module.js';

// Routines are illustrative, not biographies of the people named in the cards.
export function buildStreetLife({parent,person,cart,roads,collide,rnd}) {
  const actors=[];
  function safe(p){if(!collide(...p))return p;for(let r=1;r<18;r++)for(let i=0;i<16;i++){const q=[p[0]+Math.cos(i*Math.PI/8)*r,p[1]+Math.sin(i*Math.PI/8)*r];if(!collide(...q))return q;}return [319,6.5];}
  function add(path,isCart=false,kind='walk',phase=0) {
    path=path.map(safe);const group=isCart?cart():person(.94+rnd()*.14);parent.add(group);
    group.name=kind;group.position.set(path[0][0],.12,path[0][1]);
    const a={group,path,isCart,kind,index:1,direction:1,speed:isCart?1.45:.72+rnd()*.35,wait:phase,clock:rnd()*6};
    if(kind==='unload'){
      const crate=new THREE.Mesh(new THREE.BoxGeometry(.52,.4,.42),new THREE.MeshStandardMaterial({color:'#897252',roughness:.95}));
      crate.position.set(0,1.1,-.36);group.add(crate);a.crate=crate;
    }
    actors.push(a);return a;
  }
  // Two lanes on the main street and different side streets, with stops at ends.
  const main=roads.filter(r=>r.main);
  for(let i=0;i<4;i++){
    const r=main[(i+1)%main.length],dx=r.b[0]-r.a[0],dz=r.b[1]-r.a[1],len=Math.hypot(dx,dz),side=i%2?3:-3;
    add([r.a,r.b].map(p=>[p[0]-dz/len*side,p[1]+dx/len*side]),true,'delivery',i*2);
  }
  const candidates=[...roads.filter(r=>!r.main),...main];
  for(let i=0;i<12;i++){
    const r=candidates[(i*3)%candidates.length],dx=r.b[0]-r.a[0],dz=r.b[1]-r.a[1],len=Math.hypot(dx,dz),off=(r.width/2-.85)*(i%2?1:-1);
    const route=[.13,.5,.87].map(t=>[r.a[0]+dx*t-dz/len*off,r.a[1]+dz*t+dx/len*off]);
    if(i%2)route.reverse();add(route,false,'street',i*.4);
  }
  add([[314.5,-35],[314.5,6.5],[325,6.5]],false,'church-visit');
  add([[298,-32],[278,-29],[264,-43],[263,-52]],false,'inn-visit',3);
  const pairA=add([[310,12],[310.3,12.2]],false,'conversation');
  const pairB=add([[311.2,12],[311.1,12.3]],false,'conversation');
  pairA.group.rotation.y=-Math.PI/2;pairB.group.rotation.y=Math.PI/2;
  const delivery=add([[245,-87],[245,-84]],true,'parked-cart');
  delivery.group.rotation.y=Math.PI/2;
  add([[247,-87],[253,-86]],false,'unload',1);
  function update(dt,time,active){
    if(!active||!parent.visible)return;
    for(const a of actors){
      a.clock+=dt;const data=a.group.userData;
      if(a.kind==='conversation'){
        data.arms?.forEach((arm,i)=>arm.rotation.x=Math.sin(a.clock*1.7+i)*.12-.1);continue;
      }
      if(a.kind==='parked-cart')continue;
      if(a.wait>0){a.wait-=dt;data.legs?.forEach(l=>l.rotation.x=0);continue;}
      const target=a.path[a.index],p=a.group.position,dx=target[0]-p.x,dz=target[1]-p.z,d=Math.hypot(dx,dz),step=Math.min(a.speed*dt,d);
      let moving=false;
      if(d>.04){
        const x=p.x+dx/d*step,z=p.z+dz/d*step;
        if(!collide(x,z)){p.x=x;p.z=z;moving=true;a.group.rotation.y=Math.atan2(-dx,-dz);}
        else {a.direction*=-1;a.index=THREE.MathUtils.clamp(a.index+a.direction,0,a.path.length-1);a.wait=1;}
      }else {
        if(a.index===a.path.length-1||a.index===0){a.direction*=-1;a.wait=a.isCart?6:a.kind.endsWith('visit')?9:a.kind==='unload'?3:2+rnd()*4;if(a.crate)a.crate.visible=!a.crate.visible;}
        a.index+=a.direction;
      }
      if(moving){
        const gait=Math.sin(a.clock*(a.isCart?7:4.5)*a.speed);
        data.legs?.forEach((l,i)=>l.rotation.x=gait*(i%2?-1:1)*.35);
        data.arms?.forEach((l,i)=>l.rotation.x=gait*(i%2?1:-1)*.16);
        data.wheels?.forEach(w=>w.rotation.y-=step/.5);
      }
    }
  }
  return {actors,update};
}
