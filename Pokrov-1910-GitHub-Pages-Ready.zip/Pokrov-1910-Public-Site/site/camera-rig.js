import * as THREE from './assets/three.module.js';

export function makeCamera(mode,aspect) {
  if(mode==='iso'||mode==='plan'){
    const span=900,c=new THREE.OrthographicCamera(-span*aspect/2,span*aspect/2,span/2,-span/2,1,3400);
    c.userData.span=span;return c;
  }
  return new THREE.PerspectiveCamera(mode==='walk'?67:47,aspect,mode==='walk'?.15:3,mode==='walk'?1900:3400);
}
export function resizeCamera(camera,aspect){
  if(camera.isOrthographicCamera){const h=camera.userData.span;camera.left=-h*aspect/2;camera.right=h*aspect/2;camera.top=h/2;camera.bottom=-h/2;}
  else camera.aspect=aspect;camera.updateProjectionMatrix();
}
export const ISO_DIRECTION=new THREE.Vector3(-1,1,1).normalize();
export function sceneRect(width,height,comparison){
  if(!comparison)return {x:0,y:0,width,height};
  if(width>=700)return {x:0,y:0,width:Math.round(width*.57),height};
  // Keep the 3D model above the mobile photograph panel, below navigation.
  const bottom=Math.round(125+height*.36+10),top=206;
  return {x:0,y:bottom,width,height:Math.max(80,height-bottom-top)};
}
export function metresPerPixel(camera,height,target){
  return camera.isOrthographicCamera?(camera.top-camera.bottom)/camera.zoom/height:2*camera.position.distanceTo(target)*Math.tan(camera.fov*Math.PI/360)/height;
}
