import * as THREE from './assets/three.module.js';
import { STREET_INFRASTRUCTURE } from './street-infrastructure-data.js';
import { createStreetLightField } from './street-light-field.js';

const smooth=(a,b,x)=>{const t=THREE.MathUtils.clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
export const eveningState=hour=>({dusk:smooth(17.75,21,hour),lamps:smooth(18.5,20.5,hour)});

// Periodic, metre-scaled cobbles extend the existing procedural road material.
// Their colour and laying pattern are illustrative, not a surveyed pavement.
export function createPavingMaterial(){
  const size=512,cols=20,rows=24,albedo=new Uint8Array(size*size*4),height=new Uint8Array(size*size*4),roughness=new Uint8Array(size*size*4);
  const hash=(x,y,k=0)=>{let n=Math.imul(x+101,374761393)^Math.imul(y+113,668265263)^Math.imul(k+7,1274126177);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967296;};
  const sites=[];
  for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)sites.push({x:x+.5+(hash(x,y)-.5)*.52,y:y+.5+(hash(x,y,1)-.5)*.48,tone:hash(x,y,2)});
  for(let py=0;py<size;py++)for(let px=0;px<size;px++){
    const u=px/size*cols,v=py/size*rows,cx=Math.floor(u),cy=Math.floor(v);let first=Infinity,second=Infinity,stone;
    for(let oy=-1;oy<=1;oy++)for(let ox=-1;ox<=1;ox++){
      const ix=cx+ox,iy=cy+oy,wx=(ix+cols)%cols,wy=(iy+rows)%rows,s=sites[wy*cols+wx];
      const dx=(u-(s.x+ix-wx)),dy=(v-(s.y+iy-wy))*.84,d=dx*dx+dy*dy;
      if(d<first){second=first;first=d;stone=s;}else if(d<second)second=d;
    }
    const gap=Math.sqrt(second)-Math.sqrt(first),edge=smooth(.018,.145,gap),grain=(hash(px,py,3)-.5)*9;
    const crown=edge*(.73+.27*(1-Math.min(1,Math.sqrt(first)))),tone=142+stone.tone*29+grain;
    const i=(py*size+px)*4;
    for(let c=0;c<3;c++){
      albedo[i+c]=Math.round(THREE.MathUtils.lerp([109,101,85][c],tone+[7,4,-4][c],edge));
      height[i+c]=Math.round(crown*243);
      roughness[i+c]=Math.round(THREE.MathUtils.lerp(246,205+stone.tone*25,edge));
    }
    albedo[i+3]=height[i+3]=roughness[i+3]=255;
  }
  function texture(data,srgb=false){const t=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.magFilter=THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.generateMipmaps=true;if(srgb)t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;return t;}
  const map=texture(albedo,true),bumpMap=texture(height),roughnessMap=texture(roughness);
  const material=new THREE.MeshStandardMaterial({color:'#ffffff',map,bumpMap,bumpScale:.045,roughnessMap,roughness:1});
  material.name='interpretative-cobblestone';
  function setQuality(value,maxAnisotropy=4){
    const bump=value==='low'?null:bumpMap;
    if(material.bumpMap!==bump){material.bumpMap=bump;material.needsUpdate=true;}
    for(const t of [map,bumpMap,roughnessMap]){t.anisotropy=Math.min(maxAnisotropy,value==='low'?2:8);t.needsUpdate=true;}
  }
  return {material,setQuality};
}

// Join contiguous GIS fragments before sampling; a bend must not restart a row
// of lamps. Gaps in the supplied street network are deliberately retained.
function roadChains(roads){
  const pool=roads.map(r=>({...r,a:[...r.a],b:[...r.b]})),chains=[];
  const close=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])<.2;
  while(pool.length){
    const chain=[pool.shift()];let extended=true;
    while(extended){
      extended=false;
      for(let i=0;i<pool.length;i++){
        const r=pool[i],end=chain.at(-1).b,start=chain[0].a;
        if(close(end,r.a))chain.push(r);
        else if(close(end,r.b))chain.push({...r,a:r.b,b:r.a});
        else if(close(start,r.b))chain.unshift(r);
        else if(close(start,r.a))chain.unshift({...r,a:r.b,b:r.a});
        else continue;
        pool.splice(i,1);extended=true;break;
      }
    }
    chains.push(chain);
  }
  return chains;
}

export function buildStreetLighting({scene,roads,box,cylinder,hippedRoof,palette,collide,nearRoad,solids,exclusions=[],landmarkPoints=[]}){
  const posts=[],iron=new THREE.MeshStandardMaterial({color:'#343b36',roughness:.72,metalness:.42});
  const pane=new THREE.MeshStandardMaterial({color:'#bec4ae',roughness:.23,metalness:.1,transparent:true,opacity:.28,depthWrite:false});
  const flame=new THREE.MeshBasicMaterial({color:'#ffe0a1',toneMapped:false,transparent:true,opacity:0,depthWrite:false});
  const nightMaterials={pane,flame};
  const groups=STREET_INFRASTRUCTURE.pavedNames.map((name,i)=>({name,roads:roads.filter(r=>r.name===name),spacing:i===0?STREET_INFRASTRUCTURE.mainLampSpacing:STREET_INFRASTRUCTURE.otherLampSpacing}));
  const approaches=roads.filter(r=>!STREET_INFRASTRUCTURE.pavedNames.includes(r.name));
  for(const modern of new Set(approaches.map(r=>r.modern)))groups.push({name:modern,roads:approaches.filter(r=>r.modern===modern),spacing:STREET_INFRASTRUCTURE.approachLampSpacing,approach:true});
  for(const {name,roads:selected,spacing,approach} of groups){
    for(const chain of roadChains(selected))for(const side of [-1,1]){
      let travelled=0,next=23+(side>0?spacing/2:0);
      for(const road of chain){
        const dx=road.b[0]-road.a[0],dz=road.b[1]-road.a[1],length=Math.hypot(dx,dz);if(length<.01)continue;
        while(next<travelled+length){
          const t=next-travelled,offset=road.width/2+1.65;
          const x=road.a[0]+dx*t/length-dz/length*offset*side,z=road.a[1]+dz*t/length+dx/length*offset*side;
          next+=spacing;
          if(approach&&!landmarkPoints.some(p=>Math.hypot(x-p[0],z-p[1])<STREET_INFRASTRUCTURE.approachRadius))continue;
          if(nearRoad(x,z,.9)||collide(x,z,1.35)||exclusions.some(p=>Math.hypot(x-p[0],z-p[1])<5)||posts.some(p=>Math.hypot(x-p.x,z-p.z)<STREET_INFRASTRUCTURE.minimumLampSeparation))continue;
          // Wooden standard, iron socket and bands, reservoir, glazed cage,
          // folded metal hood and vent. Fuel and dimensions remain conjectural.
          const angle=Math.atan2(-dz,dx);
          cylinder(x,1.65,z,.105,3.25,palette.darkwood);
          cylinder(x,.30,z,.145,.44,iron);
          for(const y of [.54,2.83,3.16])cylinder(x,y,z,.12,.075,iron);
          box(x,3.30,z,.56,.11,.56,iron,angle);
          cylinder(x,3.43,z,.12,.18,iron);
          box(x,3.68,z,.47,.61,.47,pane,angle);
          for(const sx of [-1,1])for(const sz of [-1,1]){
            const lx=sx*.25,lz=sz*.25,c=Math.cos(angle),s=Math.sin(angle);
            box(x+c*lx+s*lz,3.68,z-s*lx+c*lz,.028,.68,.028,iron,angle);
          }
          box(x,4.01,z,.59,.06,.59,iron,angle);
          hippedRoof(x,z,.73,.73,4.04,.25,iron,angle);
          cylinder(x,4.32,z,.075,.16,iron);
          box(x,4.42,z,.20,.035,.20,iron,angle);
          cylinder(x,3.60,z,.072,.24,flame);
          posts.push({x,z,name,angle,width:road.width});
          solids.push({x,z,w:.30,d:.30,angle:0,radius:.22,category:'street-lamps'});
        }
        travelled+=length;
      }
    }
  }
  const glowMaterial=new THREE.ShaderMaterial({
    uniforms:{strength:{value:0}},transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
    vertexShader:'varying vec2 vUv; void main(){vUv=uv; vec4 centre=modelViewMatrix*instanceMatrix*vec4(0.0,0.0,0.0,1.0); centre.xy+=position.xy; gl_Position=projectionMatrix*centre;}',
    fragmentShader:'uniform float strength; varying vec2 vUv; void main(){float r=length(vUv-0.5)*2.0; float a=pow(max(0.0,1.0-r),2.4)*strength; gl_FragColor=vec4(1.0,0.64,0.28,a*0.85);}'
  });
  const halos=new THREE.InstancedMesh(new THREE.PlaneGeometry(2.8,2.8),glowMaterial,posts.length),matrix=new THREE.Matrix4();
  posts.forEach((p,i)=>{matrix.makeTranslation(p.x,3.65,p.z);halos.setMatrixAt(i,matrix);});
  halos.name='lantern-glow';halos.instanceMatrix.needsUpdate=true;halos.frustumCulled=false;halos.visible=false;scene.add(halos);
  const field=createStreetLightField(posts);
  function setTime(hour){
    const activation=eveningState(hour).lamps;
    flame.opacity=activation;pane.opacity=.28+activation*.15;pane.emissive.set('#ffd092');pane.emissiveIntensity=activation*2.4;
    glowMaterial.uniforms.strength.value=activation;halos.visible=activation>.005;
    field.setStrength(activation);
  }
  return {posts,field,nightMaterials,halos,setTime,setQuality:field.setQuality,bindMaterials:field.applyToScene};
}
