import * as THREE from './assets/three.module.js';
import { GEOGRAPHY } from './geography.js';

// Lenina 94, not the neighbouring inn at Lenina 92.
// Surviving front elevation: Konstantin Losevsky's 2023 photograph, credited
// in heritage-photos.js. Heights, historic colours, rear and yard are inferred.
export const KORNILOVA = {
  angle:.145, width:37, depth:17.3, eave:8.86, ridge:11.18,
  bays:[-16.8,-15.03,-11.96,-10.13,-8.33,-5.88,-3.91,-1.67,.19,1.95,4.14,5.79,7.43,9.45,11.35,13.32,15.33,17.46],
  front:8.65, windowBack:8.23, door:.19,
};

export function buildKornilova({setBuilding,setPart,push,box,lbox,local,palette,surfaceMaterials,solids,fenceSegments,landmarkBounds}){
  const {angle:a,width:w,depth:d,front:f,bays}=KORNILOVA;
  const [x,z]=GEOGRAPHY.landmarks.inn.point;
  const material=(name,color,kind='plaster',extra={})=>{
    const m=new THREE.MeshStandardMaterial({color,roughness:.9,...extra});
    m.name='kornilova/'+name;return kind?surfaceMaterials.finish(m,kind):m;
  };
  const plaster=material('ochre-limewash','#d1bc88');
  const trim=material('limestone-trim','#e3dbc6');
  const cornice=material('ochre-cornice','#927b60');
  const plinth=material('weathered-plinth','#8b8472');
  const frame=material('painted-window-wood','#68614e','door');
  const door=material('panelled-oak','#a4987e','door');
  const timber=material('yard-timber','#c5baa4','wood');
  const roof=material('standing-seam-roof','#555e5a','roof');
  const flashing=material('metal-flashing','#60685e',null,{metalness:.45,roughness:.65});
  const dark=material('window-depth','#242b28',null);
  const brick=material('chimney-brick','#c58d76','brick');brick.color.set('#c8b8a9');
  const glass=['#4d5a58','#65716a','#415151','#646256'].map((c,i)=>material('glass-'+i,c,null,{metalness:.1,roughness:.21,envMapIntensity:.85,emissive:'#efb975',emissiveIntensity:0}));
  const B=(lx,y,lz,ww,hh,dd,m)=>lbox(x,z,a,lx,y,lz,ww,hh,dd,m);
  const emit=(g,m,lx=0,y=0,lz=0,rotation=a,category='known')=>{
    const p=local(x,z,a,lx,lz);push(g,m,p[0],y,p[1],1,1,1,rotation,category);g.dispose();
  };
  function extrude(shape,depth,m,lx,y,lz,rotation=a){
    emit(new THREE.ExtrudeGeometry(shape,{depth,bevelEnabled:false,curveSegments:12,steps:1}),m,lx,y,lz,rotation);
  }
  function rect(left,bottom,width,height){
    const s=new THREE.Shape();s.moveTo(left,bottom);s.lineTo(left+width,bottom);s.lineTo(left+width,bottom+height);s.lineTo(left,bottom+height);s.closePath();return s;
  }
  // A shallow segmental arch, unlike the former rectangle with a pasted cap.
  function opening(cx,bottom,width,height,rise=.16,Type=THREE.Shape){
    const s=new Type();s.moveTo(cx-width/2,bottom);s.lineTo(cx+width/2,bottom);s.lineTo(cx+width/2,bottom+height-rise);
    s.quadraticCurveTo(cx,bottom+height+rise,cx-width/2,bottom+height-rise);s.closePath();return s;
  }
  function arcBand(cx,bottom,width,height,rise,thickness,depth,m,zz,rotation=a){
    const s=opening(cx,bottom-thickness,width+2*thickness,height+2*thickness,rise+thickness*.3);
    s.holes.push(opening(cx,bottom,width,height,rise,THREE.Path));extrude(s,depth,m,0,0,zz,rotation);
  }
  function rod(p1,p2,r,m){
    const v1=new THREE.Vector3(...p1),v2=new THREE.Vector3(...p2),delta=v2.clone().sub(v1);
    const g=new THREE.CylinderGeometry(r,r,delta.length(),7);
    g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));
    g.translate(...v1.add(v2).multiplyScalar(.5).toArray());emit(g,m);
  }
  function beam(p1,p2,width,depth,m){
    const v1=new THREE.Vector3(...p1),v2=new THREE.Vector3(...p2),delta=v2.clone().sub(v1);
    const g=new THREE.BoxGeometry(width,delta.length(),depth);
    g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));
    g.translate(...v1.add(v2).multiplyScalar(.5).toArray());emit(g,m);
  }
  function closedMesh(vertices,triangles,m){
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices.flat(),3));g.setIndex(triangles.flat());g.computeVertexNormals();
    const flat=g.toNonIndexed();g.dispose();flat.computeVertexNormals();emit(flat,m);
  }

  setBuilding('inn');setPart('foundation');
  B(0,.105,0,w+.3,.87,d+.3,plinth);
  B(0,.60,0,w+.14,.16,d+.14,trim);
  // Masonry joints have depth and are restrained to the stone base.
  for(let i=0;i<25;i++)B(-18+i*1.48,.27,f+.161,.022,.36,.014,cornice);
  setPart('walls');
  const front=rect(-w/2,.68,w,7.92);
  for(let i=0;i<bays.length;i++){
    front.holes.push(opening(bays[i],5.18,1.18,2.04,.14,THREE.Path));
    front.holes.push(opening(bays[i],i===8?.69:1.22,i===8?1.64:1.38,i===8?2.68:2.10,.20,THREE.Path));
  }
  extrude(front,.60,plaster,0,0,f-.60);
  // Rear and sides have real apertures too; their arrangement is interpretive.
  const rearBays=[-15,-11.2,-7.4,-3.6,.2,4,7.8,11.6,15.4];
  const rear=rect(-w/2,.68,w,7.92);
  for(const cx of rearBays)for(const yy of [1.3,5.18])rear.holes.push(opening(cx,yy,1.22,1.95,.12,THREE.Path));
  extrude(rear,.6,plaster,0,0,-f+.6,a+Math.PI);
  for(const sign of [-1,1]){
    const side=rect(-d/2+.60,.68,d-1.20,7.92);
    for(const cx of [-4.9,0,4.9])for(const yy of [1.3,5.18])side.holes.push(opening(cx,yy,1.14,1.95,.12,THREE.Path));
    extrude(side,.60,plaster,sign*(w/2-.6),0,0,a+sign*Math.PI/2);
  }
  // Opaque floor and ceiling prevent an empty, see-through building.
  B(0,4.18,0,w-1.2,.28,d-1.2,palette.reveal);
  B(0,8.47,0,w-1.2,.20,d-1.2,palette.reveal);

  setPart('details');
  function window(cx,bottom,width,height,index,zz=f,rotation=a,rise=.14){
    // For rear/sides use a façade-local origin and outward depth.
    const origin=rotation===a?[x,z]:rotation===a+Math.PI?[x,z]:local(x,z,a,Math.sign(rotation-a)*(w/2-f),0);
    const face=(shape,dep,m,depth)=>{
      const g=new THREE.ExtrudeGeometry(shape,{depth:dep,bevelEnabled:false,curveSegments:10});
      const p=local(origin[0],origin[1],rotation,0,f+depth);push(g,m,p[0],0,p[1],1,1,1,rotation);g.dispose();
    };
    const detail=(xx,yy,depth,ww,hh,dd,m)=>lbox(origin[0],origin[1],rotation,xx,yy,f+depth,ww,hh,dd,m);
    const outer=opening(cx,bottom-.115,width+.23,height+.23,rise+.025);
    outer.holes.push(opening(cx,bottom,width,height,rise,THREE.Path));face(outer,.08,trim,.014);
    const reveal=opening(cx,bottom,width,height,rise);
    reveal.holes.push(opening(cx,bottom+.075,width-.15,height-.15,rise,THREE.Path));face(reveal,.36,trim,-.36);
    face(opening(cx,bottom+.07,width-.14,height-.14,rise),.025,dark,-.48);
    face(opening(cx,bottom+.10,width-.20,height-.20,rise),.022,glass[index%4],-.42);
    const sash=opening(cx,bottom+.08,width-.16,height-.16,rise);
    sash.holes.push(opening(cx,bottom+.14,width-.28,height-.28,rise,THREE.Path));face(sash,.08,frame,-.37);
    detail(cx,bottom+height*.48,-.285,.056,height-.20,.085,frame);
    detail(cx,bottom+height*.73,-.28,width-.19,.058,.09,frame);
    // Thin secondary transom makes the upper lights distinct from the casement.
    detail(cx,bottom+height*.27,-.292,width-.19,.027,.07,frame);
    detail(cx,bottom-.14,.12,width+.40,.13,.48,trim);
    detail(cx,bottom-.23,.005,width+.25,.06,.29,cornice);
    if(rotation===a&&bottom>4){
      for(const dx of [-width*.39,width*.39])detail(cx+dx,bottom-.285,.06,.115,.15,.22,trim);
    }
  }
  for(let i=0;i<bays.length;i++){
    window(bays[i],5.18,1.18,2.04,i);
    if(i!==8)window(bays[i],1.22,1.38,2.10,i+2,f,a,.20);
    // Recessed rectangular panels below the ground-floor windows.
    if(i!==8){B(bays[i],.91,f+.025,1.52,.36,.045,cornice);B(bays[i],.92,f+.054,1.38,.25,.03,plaster);}
  }
  for(let i=0;i<rearBays.length;i++)for(const yy of [1.3,5.18])window(rearBays[i],yy,1.22,1.95,i+1,f,a+Math.PI,.12);
  for(const sign of [-1,1])for(let i=0;i<3;i++)for(const yy of [1.3,5.18])window([-4.9,0,4.9][i],yy,1.14,1.95,i+2,f,a+sign*Math.PI/2,.12);
  // Several profiles, not a single white bar: belt, frieze, crown, drip edge.
  for(const [yy,hh,over,m] of [[3.82,.09,.09,cornice],[3.98,.12,.19,trim],[4.10,.065,.24,cornice],[8.05,.12,.09,cornice],[8.25,.12,.16,cornice],[8.42,.12,.23,trim],[8.56,.13,.32,cornice],[8.70,.12,.44,trim]]){
    for(const sign of [-1,1]){B(0,yy,sign*(f+over/2),w+2*over,hh,over+.04,m);B(sign*(w/2+over/2),yy,0,over+.04,hh,d,m);}
  }
  for(const cx of [-18.23,18.23]){
    B(cx,4.5,f+.08,.45,7.85,.16,plaster);
    for(const yy of [.81,3.77,4.25,7.93])B(cx,yy,f+.17,.56,.13,.22,trim);
  }
  // The photographed central entrance is retained as a single timber door.
  const dx=KORNILOVA.door;
  arcBand(dx,.69,1.64,2.68,.20,.17,.12,trim,f+.012);
  extrude(opening(dx,.70,1.60,2.64,.20),.10,door,0,0,f-.40);
  B(dx,2.99,f-.281,1.35,.42,.027,glass[1]);
  for(const s of [-1,1]){
    B(dx+s*.38,1.78,f-.27,.70,1.92,.07,frame);
    for(const yy of [1.16,1.94]){B(dx+s*.38,yy,f-.22,.53,.62,.042,door);B(dx+s*.38,yy+.02,f-.194,.41,.48,.016,timber);}
    rod([dx+s*.11,1.80,f-.16],[dx+s*.11,1.96,f-.16],.023,flashing);
  }
  B(dx,2.67,f-.20,1.49,.12,.16,frame);
  for(let step=0;step<3;step++)B(dx,.14+step*.19,f+1.00-step*.29,2.72,.24,.63,plinth);
  // Compact stone landing; no modern shop staircases or advertising.
  B(dx,.65,f+.25,2.42,.14,.62,trim);
  for(const s of [-1,1])for(const zz of [f+.37,f+1.19])rod([dx+s*1.22,.34,zz],[dx+s*1.22,1.23,zz],.023,flashing);
  for(const s of [-1,1])rod([dx+s*1.22,1.23,f+.37],[dx+s*1.22,1.23,f+1.19],.029,flashing);

  setPart('roof');
  const ww=w/2+.61,dd=f+.61,ey=KORNILOVA.eave,ry=KORNILOVA.ridge,ridge=10.2;
  // Six-sided closed shell with an underside: no open back or missing soffit.
  closedMesh([[-ww,ey,-dd],[ww,ey,-dd],[ww,ey,dd],[-ww,ey,dd],[-ridge,ry,0],[ridge,ry,0]],
    [[0,4,5],[0,5,1],[3,2,5],[3,5,4],[0,3,4],[1,5,2],[0,1,2],[0,2,3]],roof);
  B(0,ey-.045,0,2*ww,.11,2*dd,plinth);
  const slope=(ry-ey)/dd;
  // Raised seams continue over each hip instead of ending in mid-air.
  for(let xx=-18.8;xx<=18.8;xx+=.59){
    const height=Math.min(ry,ey+(ww-Math.abs(xx))*(ry-ey)/(ww-ridge));
    const end=dd-(height-ey)/slope;
    for(const s of [-1,1])beam([xx,ey+.025,s*dd],[xx,height+.025,s*end],.024,.024,flashing);
  }
  beam([-ridge,ry+.03,0],[ridge,ry+.03,0],.10,.10,flashing);
  for(const sx of [-1,1])for(const sz of [-1,1])beam([sx*ww,ey+.03,sz*dd],[sx*ridge,ry+.03,0],.07,.07,flashing);
  // The fronton has its own wall, arched aperture and intersecting gable roof.
  const pc=.19,half=3.40,bottom=8.73,shoulder=10.30,peak=12.35,pz=f+.24;
  setPart('walls');
  const ped=new THREE.Shape();ped.moveTo(pc-half,bottom);ped.lineTo(pc+half,bottom);ped.lineTo(pc+half,shoulder);ped.lineTo(pc,peak);ped.lineTo(pc-half,shoulder);ped.closePath();
  function fan(cx,y,r,base=.34,Type=THREE.Shape){const s=new Type();s.moveTo(cx-r,y);s.lineTo(cx+r,y);s.lineTo(cx+r,y+base);s.absarc(cx,y+base,r,0,Math.PI,false);s.closePath();return s;}
  ped.holes.push(fan(pc,9.10,1.32,.31,THREE.Path));extrude(ped,.40,plaster,0,0,pz-.40);
  // Dormer volume joins the main roof and remains closed from every view.
  const pedBody=new THREE.Shape();pedBody.moveTo(pc-half,bottom);pedBody.lineTo(pc+half,bottom);pedBody.lineTo(pc+half,shoulder);pedBody.lineTo(pc,peak);pedBody.lineTo(pc-half,shoulder);pedBody.closePath();
  extrude(pedBody,6.55,plaster,0,0,1.80);
  setPart('roof');
  closedMesh([[pc-half-.14,shoulder+.08,pz+.20],[pc,peak+.11,pz+.20],[pc+half+.14,shoulder+.08,pz+.20],[pc-half-.14,shoulder+.08,1.64],[pc,peak+.11,1.64],[pc+half+.14,shoulder+.08,1.64]],
    [[0,4,3],[0,1,4],[1,5,4],[1,2,5],[0,2,1],[3,4,5],[0,5,2],[0,3,5]],roof);
  setPart('details');
  const band=fan(pc,8.99,1.45,.39);band.holes.push(fan(pc,9.10,1.32,.31,THREE.Path));extrude(band,.13,trim,0,0,pz+.014);
  extrude(fan(pc,9.12,1.28,.30),.025,dark,0,0,pz-.37);
  extrude(fan(pc,9.14,1.24,.29),.035,glass[2],0,0,pz-.31);
  for(const theta of [Math.PI/4,Math.PI/2,Math.PI*3/4])beam([pc,9.41,pz-.23],[pc+Math.cos(theta)*1.22,9.41+Math.sin(theta)*1.22,pz-.23],.035,.045,trim);
  B(pc,9.39,pz-.23,2.48,.04,.06,trim);B(pc,9.01,pz+.06,3.12,.13,.45,trim);
  for(const sign of [-1,1]){B(pc+sign*(half-.12),9.50,pz+.05,.25,1.50,.12,cornice);beam([pc+sign*(half+.1),shoulder+.025,pz+.20],[pc,peak+.08,pz+.20],.13,.14,cornice);}
  setPart('roof');
  // Modest masonry chimney stacks; modern attic windows are deliberately absent.
  for(const cx of [-11,8]){
    B(cx,11.40,-1.1,.66,2.32,.91,brick);B(cx,12.48,-1.1,.84,.17,1.07,cornice);B(cx,12.60,-1.1,.68,.08,.91,flashing);B(cx,12.648,-1.1,.43,.017,.63,dark);
    B(cx,10.95,-1.1,1.01,.14,1.22,flashing);
  }
  setPart('details');
  // Gutters, brackets, swan necks and drain shoes read at street distance.
  for(const s of [-1,1]){
    rod([-ww,8.76,s*(dd-.03)],[ww,8.76,s*(dd-.03)],.073,flashing);
    for(let xx=-18;xx<19;xx+=1.9)B(xx,8.66,s*(dd-.13),.05,.15,.19,flashing);
  }
  for(const cx of [-17.96,-3.25,17.98]){
    rod([cx,8.74,dd],[cx,8.35,f+.25],.068,flashing);rod([cx,8.35,f+.25],[cx,.56,f+.25],.068,flashing);rod([cx,.56,f+.25],[cx,.29,f+.66],.068,flashing);
    for(const yy of [1.0,3.1,5.3,7.5])B(cx,yy,f+.17,.20,.055,.24,flashing);
  }
  solids.push({x,z,w:w+.35,d:d+.35,angle:a,radius:Math.hypot(w,d)/2+.4,category:'known'});
  const porch=local(x,z,a,dx,f+.70);solids.push({x:porch[0],z:porch[1],w:2.72,d:1.45,angle:a,radius:1.6,category:'known'});
  landmarkBounds.inn=new THREE.Box3(new THREE.Vector3(x-21,0,z-12),new THREE.Vector3(x+22,13.2,z+12));
  setBuilding(null);

  // The yard is an explicitly interpretive parcel, laid out clear of the road.
  function yardFence(p1,p2,height=1.83,baseY=-.25){
    const [xx,zz]=p1,[ex,ez]=p2,len=Math.hypot(ex-xx,ez-zz),fa=Math.atan2(-(ez-zz),ex-xx);
    fenceSegments.push({a:p1,b:p2,minX:Math.min(xx,ex),maxX:Math.max(xx,ex),minZ:Math.min(zz,ez),maxZ:Math.max(zz,ez)});
    const n=Math.ceil(len/.20);
    for(let i=0;i<n;i++){const t=(i+.5)/n,h=height+.018*Math.sin(i*3.7);box(xx+(ex-xx)*t,baseY+h/2,zz+(ez-zz)*t,len/n-.015,h,.065,timber,fa,'fences');}
    for(const y of [.42,1.39])box((xx+ex)/2,baseY+y,(zz+ez)/2,len,.10,.13,door,fa,'fences');
    for(let t=0;t<=len;t+=2.5)box(xx+(ex-xx)*t/len,baseY+height*.52,zz+(ez-zz)*t/len,.13,height+ .12,.15,door,fa,'fences');
  }
  yardFence([242,-96],[279,-96]);yardFence([279,-96],[279,-80]);yardFence([242,-96],[240.7,-80]);
  const gate1=local(x,z,a,19.05,f),gate2=local(x,z,a,23.45,f);
  for(const p of [gate1,gate2]){
    box(p[0],1.04,p[1],.51,2.58,.51,plaster,a,'fences');box(p[0],2.35,p[1],.67,.17,.67,trim,a,'fences');box(p[0],0,p[1],.62,.50,.62,plinth,a,'fences');
    solids.push({x:p[0],z:p[1],w:.67,d:.67,angle:a,radius:.48,category:'fences'});
  }
  // Open leaves leave a clear 3.5 m drive and are collidable when fences show.
  yardFence(gate1,local(x,z,a,19.45,f-2.12),1.85);yardFence(gate2,local(x,z,a,23.05,f-2.12),1.85);
  // A low timber store in the rear yard, with planked walls and lean-to roof.
  const sx=249.0,sz=-89.3;
  box(sx,.10,sz,4.3,.3,3.2,plinth,a);
  const shedWalls=new THREE.BoxGeometry(4.1,1,3),shedPosition=shedWalls.attributes.position;
  for(let i=0;i<shedPosition.count;i++)shedPosition.setY(i,shedPosition.getY(i)>0?2.71-Math.tan(.15)*shedPosition.getZ(i)-.065:.08);
  shedWalls.computeVertexNormals();push(shedWalls,timber,sx,0,sz,1,1,1,a);shedWalls.dispose();
  for(let i=0;i<21;i++)lbox(sx,sz,a,-1.96+i*.196,1.25,1.52,.023,2.34,.047,door);
  lbox(sx,sz,a,.8,1.08,1.55,1.23,2.08,.07,door);for(const yy of [.45,1.66])lbox(sx,sz,a,.8,yy,1.61,1.16,.10,.09,timber);
  const shedRoof=new THREE.BoxGeometry(4.52,.13,3.55);shedRoof.rotateX(.15);push(shedRoof,roof,sx,2.71,sz,1,1,1,a);shedRoof.dispose();
  solids.push({x:sx,z:sz,w:4.5,d:3.55,angle:a,radius:2.9,category:'known'});
  // Stacked firewood, individually staved barrels and a usable yard bench.
  for(let row=0;row<3;row++)for(let col=0;col<7-row;col++){
    const g=new THREE.CylinderGeometry(.12,.135,1.16,8);g.rotateZ(Math.PI/2);push(g,timber,253.1, .17+row*.23,-91.6+col*.25+row*.12,1,1,1,a);g.dispose();
  }
  for(const [bx,bz] of [[274.9,-88.5],[275.5,-90.3]]){
    const body=new THREE.LatheGeometry([[.36,0],[.41,.17],[.46,.56],[.43,.95],[.36,1.1]].map(p=>new THREE.Vector2(...p)),16);
    push(body,timber,bx,.08,bz);body.dispose();
    for(const yy of [.24,.64,1.06]){const hoop=new THREE.TorusGeometry(yy===.64?.465:.414,.022,5,20);hoop.rotateX(Math.PI/2);push(hoop,flashing,bx,yy,bz);hoop.dispose();}
    const lid=new THREE.CylinderGeometry(.358,.358,.045,16);push(lid,door,bx,1.19,bz);lid.dispose();
    solids.push({x:bx,z:bz,w:.93,d:.93,angle:0,radius:.66,category:'known'});
  }
  for(let j=0;j<3;j++)box(272,.56,-93.3+j*.16,2.25,.07,.13,timber);
  for(const xx of [271.13,272.87])box(xx,.29,-93.14,.13,.56,.54,door);
  box(272,.94,-93.46,2.25,.12,.08,timber);box(272,1.14,-93.46,2.25,.12,.08,timber);
  for(const xx of [271.13,272.87])box(xx,.82,-93.46,.09,.78,.10,door);
  solids.push({x:272,z:-93.3,w:2.25,d:.65,angle:0,radius:1.2,category:'known'});
  return {setTime(hour){const night=THREE.MathUtils.smoothstep(hour,18.5,20.5);glass[1].emissiveIntensity=night*.34;glass[3].emissiveIntensity=night*.22;}};
}
