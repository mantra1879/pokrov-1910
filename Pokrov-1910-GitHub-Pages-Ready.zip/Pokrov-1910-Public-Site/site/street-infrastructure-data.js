// Main-street infrastructure is an interpretation, not an archival inventory.
// Shared by the surface baker and the runtime lamp placement.
export const STREET_INFRASTRUCTURE = {"pavedNames":["Московская улица","Ивановская улица","Дворянская улица"],"mainLampSpacing":32,"otherLampSpacing":38,"approachLampSpacing":34,"approachRadius":65,"minimumLampSeparation":16,"source":"https://www.pokrovcity.ru/city/history/free_city_cover.php"};
