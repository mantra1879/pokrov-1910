import * as THREE from './assets/three.module.js';

// Fit the existing sunlight map to the part of town being inspected. Snapping
// in the light's own plane prevents a stationary edge crawling across texels.
export function fitSunShadow(light,camera,target,view,force=false){
  const offset=light.userData.sunOffset;if(!offset)return false;
  const span=camera.isOrthographicCamera?(camera.top-camera.bottom)/camera.zoom:2*camera.position.distanceTo(target)*Math.tan(THREE.MathUtils.degToRad(camera.fov/2));
  const aspect=camera.isOrthographicCamera?(camera.right-camera.left)/(camera.top-camera.bottom):camera.aspect;
  const half=view==='walk'?145:Math.ceil(THREE.MathUtils.clamp(span*Math.max(1,aspect)*1.1,155,950)/25)*25;
  const centre=view==='walk'?camera.position.clone().add(camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(35)):target.clone();centre.y=0;
  const direction=offset.clone().normalize(),right=new THREE.Vector3(0,1,0).cross(direction).normalize(),up=direction.clone().cross(right);
  const texel=2*half/light.shadow.mapSize.x;
  const snapped=right.clone().multiplyScalar(Math.round(centre.dot(right)/texel)*texel).addScaledVector(up,Math.round(centre.dot(up)/texel)*texel).addScaledVector(direction,centre.dot(direction));
  const previous=light.userData.shadowFit;
  if(!force&&previous&&previous.half===half&&previous.centre.distanceToSquared(snapped)<texel*texel*.05&&previous.offset.distanceToSquared(offset)<.001)return false;
  light.target.position.copy(snapped);light.position.copy(snapped).add(offset);light.target.updateMatrixWorld();
  Object.assign(light.shadow.camera,{left:-half,right:half,top:half,bottom:-half,near:10,far:2400});light.shadow.camera.updateProjectionMatrix();
  light.shadow.normalBias=Math.max(.045,texel*.32);light.shadow.bias=-.00002;
  light.userData.shadowFit={half,centre:snapped,offset:offset.clone()};return true;
}
