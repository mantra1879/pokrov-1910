// Interpretative churchyard boundaries. Each enclosure is a single rectangle
// aligned with its neighbouring street, with a deliberate gap at the entrance.
// Coordinates are metres in the same frame as geography.js; temples do not move.
export const CHURCH_ENCLOSURES={
  pokrov:{centre:[353.6,6.6],width:48,depth:47,angle:.126,gate:[-10,5]},
  trinity:{centre:[-15.5,-70.35],width:66,depth:58,angle:.165,gate:[-4,4]}
};

export function enclosureLayout(id){
  const {centre:[x,z],width:w,depth:d,angle:a,gate}=CHURCH_ENCLOSURES[id];
  const point=(lx,lz)=>[x+Math.cos(a)*lx+Math.sin(a)*lz,z-Math.sin(a)*lx+Math.cos(a)*lz];
  const corners=[point(-w/2,-d/2),point(w/2,-d/2),point(w/2,d/2),point(-w/2,d/2)];
  const gateEnds=[point(-w/2,gate[0]),point(-w/2,gate[1])];
  return {corners,gateEnds,angle:a,segments:[
    [corners[0],corners[1]],[corners[1],corners[2]],[corners[2],corners[3]],
    [corners[3],gateEnds[1]],[gateEnds[0],corners[0]]
  ]};
}
