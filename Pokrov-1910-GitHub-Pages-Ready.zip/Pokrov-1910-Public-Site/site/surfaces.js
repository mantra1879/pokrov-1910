import * as THREE from './assets/three.module.js';
import { SURFACES } from './surface-data.js';

// Single tessellation per visible layer: intersections contain no coincident
// road faces. World UVs remain continuous across the 160 m culling chunks.
export function buildSurfaces(push,materials) {
  for(const p of SURFACES) {
    const rings=[p.outer,...p.holes].map(r=>r.map(([x,z])=>new THREE.Vector2(x,-z)));
    const points=rings.flat();
    const triangles=THREE.ShapeUtils.triangulateShape(rings[0],rings.slice(1));
    const y=p.kind==='water'?-.08:p.kind==='bank'?-.12:.08;
    const vertices=[],uv=[];
    for(const tri of triangles){
      const pts=tri.map(i=>[Math.fround(points[i].x),Math.fround(-points[i].y)]);
      const cross=(pts[1][1]-pts[0][1])*(pts[2][0]-pts[0][0])-(pts[1][0]-pts[0][0])*(pts[2][1]-pts[0][1]);
      if(Math.abs(cross)<1e-7)continue;
      if(cross<0)pts.reverse();
      for(const [x,z] of pts){vertices.push(x,y,z);uv.push(x/6,z/6);}
    }
    const geo=new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
    geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.computeVertexNormals();
    push(geo,materials[p.kind],0,0,0,1,1,1,0,'surfaces');geo.dispose();
  }
}
