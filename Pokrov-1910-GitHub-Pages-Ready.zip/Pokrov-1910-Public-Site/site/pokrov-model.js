import * as THREE from './assets/three.module.js';
import { GEOGRAPHY } from './geography.js';

// Photograph-guided massing, not measured restoration drawings. Nave and
// western tower remain inside the surviving georeferenced footprint.
export function buildPokrov(h) {
  const {box,cylinder,hippedRoof,lathe,onion,arch,churchWindow,palette,solids,landmarkBounds,setBuilding,setPart,push}=h;
  setBuilding('pokrov');
  const white=palette.chalk,trim=palette.ivory;
  const blue=new THREE.MeshStandardMaterial({color:'#688ca4',roughness:.8});
  const gold=new THREE.MeshStandardMaterial({color:'#c9aa58',metalness:.65,roughness:.36});
  const roof=palette.roof;
  const bx=330.9,bz=6.9,nx=359.0,nz=5.3;
  setPart('foundation');
  box(352.5,.32,5.4,32.1,.64,28.5,palette.stone);
  box(bx,.32,bz,8.1,.64,8.9,palette.stone);
  setPart('walls');
  box(347.6,3.5,5.4,21.5,6.4,27.8,white);
  box(335.5,3.0,bz,5.9,5.4,5.6,white);
  box(nx,7.5,nz,17.6,14.4,21.6,white);
  cylinder(367.0,3.9,6.5,4.65,7.2,white);
  box(bx,4.35,bz,7.8,8.1,8.5,white);
  box(bx,12.0,bz,6.0,7.2,6.4,white);
  // Open belfry: four corner piers, with an actual void and suspended bell.
  for(const dx of [-2.25,2.25])for(const dz of [-2.25,2.25])box(bx+dx,19.05,bz+dz,1.0,6.6,1.0,white);
  box(bx,22.55,bz,5.7,.6,5.7,trim);
  cylinder(bx,20.2,bz,.08,2.9,palette.iron);
  lathe(bx,18.3,bz,[[.85,0],[.9,.15],[.6,.5],[.35,1.1],[.25,1.3]],palette.metal,20);
  setPart('roof');
  hippedRoof(347.6,5.4,22.2,28.4,6.9,2.1,roof);
  hippedRoof(335.5,bz,6.2,6.1,5.75,1.35,roof);
  hippedRoof(nx,nz,18.5,22.5,14.7,2.3,roof);
  lathe(367,7.6,6.5,[[4.9,0],[4.2,.8],[2.8,1.5],[0,2.1]],roof,24);
  for(const [dx,dz,r,y,dh] of [[0,0,2.45,16.5,4.0],[-5.65,-7.2,1.35,16,2.8],[5.65,-7.2,1.35,16,2.8],[-5.65,7.2,1.35,16,2.8],[5.65,7.2,1.35,16,2.8]]) {
    cylinder(nx+dx,y+dh/2,nz+dz,r,dh,blue);
    cylinder(nx+dx,y+dh,nz+dz,r+.14,.25,trim);
    onion(nx+dx,y+dh+.15,nz+dz,r*1.35,r*2.1,gold);
    for(let k=0;k<8;k++)churchWindow(nx+dx,nz+dz,k*Math.PI/4,0,r+.015,y+.45,r*.36,dh-1.0);
  }
  lathe(bx,22.85,bz,[[3.15,0],[2.75,.75],[1.7,1.7],[1.0,2.3]],roof,24);
  cylinder(bx,26.1,bz,1.0,2.0,white);
  onion(bx,27.15,bz,1.45,2.7,palette.dome);
  setPart('details');
  for(const side of [-1,1]){
    const a=side>0?0:Math.PI;
    for(const dx of [-7,-2,3])churchWindow(346,5.4,a,dx,14.0,1.7,1.4,3.6);
    for(const dx of [-5.6,0,5.6])churchWindow(nx,nz,a,dx,10.85,5.2,1.7,5.4);
    for(let i=-3;i<=3;i++){
      const g=new THREE.TorusGeometry(.91,.12,5,14,Math.PI);
      push(g,trim,nx+i*2.45,12.8,nz+side*10.98,1,1,1,a);g.dispose();
    }
    for(const dx of [-8.6,8.6])box(nx+dx,7.4,nz+side*10.92,.55,13.8,.35,trim);
    box(nx,14.4,nz+side*11.0,18.1,.4,.5,trim);
    box(347.3,6.65,5.4+side*14.05,21.8,.3,.5,trim);
  }
  for(const y of [8.5,15.75,22.6])box(bx,y,bz,y<9?8.4:6.6,.36,y<9?9.1:6.6,trim);
  for(let side=0;side<4;side++){
    const a=side*Math.PI/2;
    churchWindow(bx,bz,a,0,3.23,10.0,1.65,4.6);
    const dx=Math.sin(a)*2.82,dz=Math.cos(a)*2.82;
    const arc=new THREE.TorusGeometry(1.65,.3,6,16,Math.PI);
    push(arc,trim,bx+dx,20.2,bz+dz,1,1,1,a);arc.dispose();
  }
  churchWindow(bx,bz,-Math.PI/2,0,3.96,.65,2.55,5.8);
  for(let j=0;j<3;j++)box(326.3-j*.32,.15+j*.12,bz,1.4-j*.15,.24,3.7-j*.2,palette.stone);
  solids.push({x:348.9,z:6.6,radius:32,polygon:GEOGRAPHY.landmarks.pokrov.outline.slice(0,-1),category:'known'});
  landmarkBounds.pokrov=new THREE.Box3(new THREE.Vector3(325,0,-10),new THREE.Vector3(373,33,21));
  setBuilding(null);
}
