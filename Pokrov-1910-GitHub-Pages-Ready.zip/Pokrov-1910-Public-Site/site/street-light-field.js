import * as THREE from './assets/three.module.js';

// A fixed spatial light list lets every lamp illuminate surfaces. Each fragment
// evaluates only nearby sources, independent of the camera or the total count.
// This uses the standard material's direct-light response, including its normal,
// albedo, roughness and specular response; it is not an emissive facade overlay.
const SLOTS=8,CELL=8,RANGE=42,POWER=560,HEIGHT=3.61;
export function createStreetLightField(posts){
  const minX=Math.floor((Math.min(...posts.map(p=>p.x),0)-RANGE)/CELL)*CELL;
  const minZ=Math.floor((Math.min(...posts.map(p=>p.z),0)-RANGE)/CELL)*CELL;
  const cols=Math.ceil((Math.max(...posts.map(p=>p.x),0)+RANGE-minX)/CELL);
  const rows=Math.ceil((Math.max(...posts.map(p=>p.z),0)+RANGE-minZ)/CELL);
  const data=new Float32Array(cols*rows*SLOTS*4),indices=new Int32Array(cols*rows*SLOTS).fill(-1);
  for(let z=0;z<rows;z++)for(let x=0;x<cols;x++){
    const wx=minX+(x+.5)*CELL,wz=minZ+(z+.5)*CELL;
    const nearest=posts.map((p,i)=>({i,p,d:Math.hypot(p.x-wx,p.z-wz)})).filter(p=>p.d<RANGE+CELL/Math.sqrt(2)).sort((a,b)=>a.d-b.d).slice(0,SLOTS);
    nearest.forEach(({p,i},slot)=>{const offset=(z*cols*SLOTS+x*SLOTS+slot);data.set([p.x,p.z,HEIGHT,RANGE],offset*4);indices[offset]=i;});
  }
  const texture=new THREE.DataTexture(data,cols*SLOTS,rows,THREE.RGBAFormat,THREE.FloatType);
  texture.minFilter=texture.magFilter=THREE.NearestFilter;texture.generateMipmaps=false;texture.needsUpdate=true;
  const uniforms={
    streetLightGrid:{value:texture},streetGridOrigin:{value:new THREE.Vector2(minX,minZ)},streetGridSize:{value:new THREE.Vector2(cols,rows)},
    streetLightStrength:{value:0},streetLightSamples:{value:6},streetLightColor:{value:new THREE.Color('#ffd092')}
  };
  const fragmentDeclarations=`
    varying vec3 vStreetWorldPosition;
    uniform highp sampler2D streetLightGrid;
    uniform vec2 streetGridOrigin;
    uniform vec2 streetGridSize;
    uniform float streetLightStrength;
    uniform int streetLightSamples;
    uniform vec3 streetLightColor;
  `;
  const directLighting=`
    #if defined(RE_Direct)
    if(streetLightStrength>0.001){
      vec2 streetCell=floor((vStreetWorldPosition.xz-streetGridOrigin)/${CELL.toFixed(1)});
      if(all(greaterThanEqual(streetCell,vec2(0.0)))&&all(lessThan(streetCell,streetGridSize))){
        for(int streetSlot=0;streetSlot<${SLOTS};streetSlot++){
          if(streetSlot>=streetLightSamples)break;
          vec2 streetUv=vec2((streetCell.x*${SLOTS.toFixed(1)}+float(streetSlot)+0.5)/(streetGridSize.x*${SLOTS.toFixed(1)}),(streetCell.y+0.5)/streetGridSize.y);
          vec4 streetSource=texture2D(streetLightGrid,streetUv);
          if(streetSource.w>0.0){
            vec3 streetDelta=vec3(streetSource.x,streetSource.z,streetSource.y)-vStreetWorldPosition;
            float streetDistanceSquared=dot(streetDelta,streetDelta);
            float streetRatio=streetDistanceSquared/(streetSource.w*streetSource.w);
            float streetFalloff=max(0.0,1.0-streetRatio*streetRatio);
            streetFalloff*=streetFalloff;
            IncidentLight streetIncident;
            streetIncident.direction=normalize((viewMatrix*vec4(streetDelta,0.0)).xyz+vec3(0.0,0.00001,0.0));
            streetIncident.color=streetLightColor*(streetLightStrength*${POWER.toFixed(1)}*streetFalloff/max(streetDistanceSquared,2.0));
            streetIncident.visible=true;
            RE_Direct(streetIncident,geometryPosition,geometryNormal,geometryViewDir,geometryClearcoatNormal,material,reflectedLight);
          }
        }
      }
    }
    #endif
  `;
  function applyToScene(scene){
    const materials=new Set();scene.traverse(mesh=>{if(mesh.isMesh)for(const material of Array.isArray(mesh.material)?mesh.material:[mesh.material])if(material.isMeshStandardMaterial)materials.add(material);});
    for(const material of materials){
      if(material.userData.streetLightField)continue;
      const previous=material.onBeforeCompile,previousKey=material.customProgramCacheKey();
      material.onBeforeCompile=function(shader,renderer){
        previous.call(this,shader,renderer);Object.assign(shader.uniforms,uniforms);
        shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vStreetWorldPosition;').replace('#include <worldpos_vertex>',`#include <worldpos_vertex>
          vec4 streetWorld=vec4(transformed,1.0);
          #ifdef USE_INSTANCING
          streetWorld=instanceMatrix*streetWorld;
          #endif
          vStreetWorldPosition=(modelMatrix*streetWorld).xyz;`);
        shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\n'+fragmentDeclarations).replace('#include <lights_fragment_end>','#include <lights_fragment_end>\n'+directLighting);
      };
      material.customProgramCacheKey=()=>previousKey+'-pokrov-street-light-field-v1';
      material.userData.streetLightField=true;material.needsUpdate=true;
    }
    return materials.size;
  }
  function setStrength(value){uniforms.streetLightStrength.value=value;}
  function setQuality(value){uniforms.streetLightSamples.value=value==='low'?4:value==='high'?8:6;}
  function candidatesAt(x,z,count=uniforms.streetLightSamples.value){
    const ix=Math.floor((x-minX)/CELL),iz=Math.floor((z-minZ)/CELL);if(ix<0||iz<0||ix>=cols||iz>=rows)return [];
    const offset=(iz*cols+ix)*SLOTS;
    return [...indices.slice(offset,offset+count)].filter(i=>i>=0).map(i=>posts[i]);
  }
  return {applyToScene,setStrength,setQuality,candidatesAt,uniforms,range:RANGE,power:POWER,height:HEIGHT,grid:{cols,rows,cell:CELL,slots:SLOTS,minX,minZ}};
}
